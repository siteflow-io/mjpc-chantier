import sys,json; sys.path.insert(0,'.')
from banc import Banc, instantane
db=instantane()
D='dictee_preparee_5e_grandes_decouvertes-5e_herge'
db['correction_dictee'][D]['autocorrection'].pop('bzzinet_azzet',None)
db['correction_dictee'][D]['copyPublishedAt']=1790000000000
b=Banc('../work/correction_dictee.html')
p=b.ouvrir('?mode=eleve&dictee='+D, db=db, session={'display':'BZZINET Azzet','classe':'5e HERGÉ'})
p.wait_for_timeout(1300)
p.query_selector_all('span.word-btn[style*="cursor: pointer"]')[0].click(); p.wait_for_timeout(200)
p.fill('input[placeholder="Tape le mot correct…"]','zzz'); p.get_by_role('button',name='✓').click(); p.wait_for_timeout(1000)
print(p.evaluate('()=>document.querySelector(".popup-overlay")&&document.querySelector(".popup-overlay").outerHTML.slice(0,1500)'))
p.screenshot(path='cap/e4_popup.png')
print(p.evaluate('()=>{const e=document.querySelector(".popup-overlay");const r=e.getBoundingClientRect();const cs=getComputedStyle(e);return [r.x,r.y,r.width,r.height,cs.position,cs.zIndex,cs.pointerEvents]}'))
print(p.evaluate('()=>{const e=document.elementFromPoint(8,700);return e&&e.outerHTML.slice(0,120)}'))
print(p.evaluate('()=>{const e=document.elementFromPoint(683,850);return e&&e.className}'))
