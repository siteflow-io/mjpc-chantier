"""Complément du 29/09 — points 232, 234, 235, par le geste (cas de Candice)."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; U='dictee_5e_chapitre_utopie-5e_herge'; C='bzzetor_czzix'; bilan=[]; now=lambda:int(time.time()*1000)
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
eC=L.erreurs(U,C); idx=[str(i) for i,e in enumerate(eC) if e.get('type')!='A']
def fiche(**x):
    f={'attestation':{'t':1},'sessionDebut':now()-20*60000,'attempts':{i:1 for i in idx},'results':{i:True for i in idx},'status':'done','styloFin':now()-60000}; f['attempts'][idx[0]]=2; f.update(x); return f
def ouvrir(heure):
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000; D['autocorrection'][C]=fiche()
    if heure: D['heure']=heure
    b=Banc(F,900,900); p=L.ouvrir(b,U,C,db); p.wait_for_timeout(1300); return b,p,p.inner_text('body').replace('\xa0',' ')
b,p,t=ouvrir({'debut':now()-30*60000,'fin':now()+25*60000})
note('232. pendant votre heure : ni la dictée corrigée ni l’analyse sur la page de fin de Candice','Ta dictée corrigée et l’analyse de tes erreurs s’afficheront à la fin de l’heure.' in t and 'TA DICTÉE CORRIGÉE' not in t.upper().replace('TA DICTÉE CORRIGÉE ET',''))
note('232. …ni le bouton 📄 : « Ta dictée autocorrigée sera disponible à la fin de l’heure. »','📄 Ta dictée autocorrigée sera disponible à la fin de l’heure.' in t and not p.get_by_role('button',name='📄 Ma dictée autocorrigée').count())
note('235. elle a fini sans rien perdre : « Tu n’as rien perdu. », sans « pour l’instant »','Tu n’as rien perdu.' in t and 'pour l’instant' not in t)
ph=[l for l in t.split('\n') if 'Pour cette dictée' in l]
note('234. sa phrase ne se contredit plus','surtout de grammaire' in (ph[0] if ph else '') and 'accent circonflexe' not in (ph[0] if ph else ''),ph[0][:170] if ph else '')
note('réseau : 0 accès au vrai hub, 0 erreur',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:120]); b.fermer()
b,p,t=ouvrir({'debut':now()-60*60000,'fin':now()+5*60000,'cloture':True,'clotureA':now()-60000})
note('232. l’heure close : la dictée corrigée, l’analyse et le 📄 reviennent','ANALYSE DE TES ERREURS' in t.upper() and p.get_by_role('button',name='📄 Ma dictée autocorrigée').count()==1); b.fermer()
b,p,t=ouvrir(None)
note('233. l’ancienne consigne « Maintenant, corrige sur ta copie au stylo vert… » a disparu','Maintenant, corrige sur ta copie' not in t and 'TA DICTÉE CORRIGÉE' in t.upper())
note('232. chez elle, sans heure lancée : tout est visible','ANALYSE DE TES ERREURS' in t.upper() and p.get_by_role('button',name='📄 Ma dictée autocorrigée').count()==1); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
