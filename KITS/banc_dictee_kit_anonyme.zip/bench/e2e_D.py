"""De bout en bout, partie D — votre heure lancée, puis la tablette en deux moitiés avec la classe neuve :
connexion au clavier dessiné avec un vrai code chiffré, binôme proposé à côté, code seul, correction d'un mot."""
import sys, copy, json, os, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
os.environ['BANC_SECURISE']='1'
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; S=json.load(open('/tmp/e2e_brevet.json')); db=S['db']; did=S['did']; att=S['attendu']
TITRE=db['correction_dictee'][did]['config']['title']; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
db['correction_dictee'][did]['copyPublishedAt']=1790000000000
# votre suivi : lancer l'heure (les binômes se calculent)
b=Banc(F,1400,900); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(1000)
p.evaluate("(t)=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes(t)&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}",TITRE); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1200)
p.get_by_role('button',name='▶ Lancer l’autocorrection').click(); p.wait_for_timeout(900)
BIN=b.lire(p,'correction_dictee/%s/binomes'%did) or {}
note('8. l’heure lancée : binômes calculés pour les %d élèves présents'%len(att),len(BIN)>=6 and all(BIN.get(v)==k for k,v in BIN.items()),json.dumps(BIN)[:160])
# codes chiffrés pour tous
for i,k in enumerate(att):
    ent=p.evaluate("async(a)=>{const sel='feed'+a[1];const e=await mjpcEmpreinte(a[0],sel);return {sel:sel,empreinte:e}}",[str(5200+i),str(i)])
    p.evaluate("(a)=>window.__FAKE_DB_SET__('codes/'+a[0],{name:a[1],classe:'3E IMPORT TEST',createdAt:Date.now(),chiffre:'v1.test',sel:a[2].sel,empreinte:a[2].empreinte})",[k,att[k][0],ent])
db=b.lire(p,''); b.fermer()
# la tablette
A=list(att.keys())[1]; nomA=att[A][0]; PA=BIN.get(A); nomP=att[PA][0] if PA in att else None
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(1000)
p.get_by_role('button',name='👥 2 élèves').click(); p.wait_for_timeout(900)
def touches(m,txt):
    for ch in txt:
        lab='espace' if ch==' ' else ('’' if ch in "'’" else ch.lower())
        if not p.evaluate("(x)=>{const mm=document.querySelectorAll('.moitie')[x[0]];const b=[...mm.querySelectorAll('button')].find(y=>y.textContent===x[1]);if(!b)return false;b.click();return true}",[m,lab]): return False
        p.wait_for_timeout(30)
    return True
iA=list(att.keys()).index(A); parts=nomA.split(' '); ok=touches(0,str(5200+iA))
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('button')].find(x=>x.textContent==='✓').click()}"); p.wait_for_timeout(150)
ok=touches(0,' '.join(parts[:-1])) and ok; p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];m.querySelectorAll('input')[2].focus()}"); p.wait_for_timeout(100); ok=touches(0,parts[-1]) and ok
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('button')].find(x=>x.textContent==='Entrer').click()}"); p.wait_for_timeout(2500)
t=p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(m=>m.innerText)")
note('9. %s se connecte au clavier dessiné (nom composé, accents) avec son vrai code'%nomA,ok and 'Mes dictées' in t[0],t[0][:100].replace('\n',' | '))
note('10. l’autre moitié propose son binôme : « Ton binôme : %s », code seul'%nomP,bool(nomP) and ('Ton binôme : '+nomP) in t[1] and 'tape ton code' in t[1])
iP=list(att.keys()).index(PA); touches(1,str(5200+iP)); p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[1];[...m.querySelectorAll('button')].find(x=>x.textContent==='Entrer').click()}"); p.wait_for_timeout(2500)
t=p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(m=>m.innerText)")
note('11. le binôme entre avec son seul code',('Mes dictées' in t[1]) and nomP in t[1])
p.evaluate("(tt)=>{const m=document.querySelectorAll('.moitie')[0];const c=[...m.querySelectorAll('div')].filter(x=>x.textContent.includes(tt)&&x.textContent.includes('Ouvrir')&&x.children.length<8);const e=c[c.length-1];const b=[...e.querySelectorAll('button,span,div')].find(x=>x.textContent.trim().startsWith('Ouvrir'));(b||e).click()}",TITRE); p.wait_for_timeout(1500)
if 'J’ai lu et compris' in p.evaluate("()=>document.querySelectorAll('.moitie')[0].innerText"):
    p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('label')].find(l=>l.textContent.includes('J’ai lu et compris')).click()}"); p.wait_for_timeout(150)
    p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('button')].find(b=>b.textContent.includes('Commencer mon autocorrection')).click()}"); p.wait_for_timeout(900)
errs=[e for e in db['correction_dictee'][did]['results'][A]['errors'] if e]; i0=[i for i,e in enumerate(errs) if e.get('type')!='A'][0]
p.evaluate("(i)=>document.querySelectorAll('.moitie')[0].querySelector('span.word-btn[data-err=\"'+i+'\"]').click()",i0); p.wait_for_timeout(400)
touches(0,errs[i0]['word']); p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('button')].find(x=>x.textContent==='✓ Valider').click()}"); p.wait_for_timeout(1700)
res=b.lire(p,'correction_dictee/%s/autocorrection/%s/results'%(did,A)) or {}
note('12. à gauche, « %s » tapé au clavier dessiné puis validé : trouvé'%errs[i0]['word'],bool((res.get(str(i0)) if isinstance(res,dict) else res[i0])))
bn=b.lire(p,'correction_dictee/%s/binomes'%did) or {}
note('13. les deux élèves de la tablette sont rangés comme binôme au hub',bn.get(A)==PA and bn.get(PA)==A)
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
