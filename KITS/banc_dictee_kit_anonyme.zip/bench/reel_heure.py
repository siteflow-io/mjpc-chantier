"""Une vraie heure courte, en temps réel, sans rien simuler : fin dans 9 minutes."""
import sys, copy, time, re; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; EK='bzzinet_azzet'
T0=time.time(); now=lambda:int(time.time()*1000)
def log(m): print('[%5.1f min] %s'%((time.time()-T0)/60,m),flush=True)
bil=[]
def note(n,ok,d=''): bil.append(ok); log(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''))
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None)
FIN=now()+int(4.6*60000); D['heure']={'debut':now()-60000,'fin':FIN}
errs=L.erreurs(DGD,EK); b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,db)
note('dès l’ouverture (4 min 36 avant la fin) : alerte orange « Plus que 5 minutes »','Plus que 5 minutes.' in p.inner_text('body'))
L.jouer(p,errs,{0:2,1:1,2:0,3:0,4:0,5:0}); p.wait_for_timeout(1500)
t=p.evaluate("()=>{const o=[...document.querySelectorAll('.popup-overlay')].pop();return o?o.innerText:''}")
note('stylo vert réel ouvert à la fin de la correction',('Tu as 2 minutes' in t) and ('1:5' in t or '2:00' in t),t[:80].replace('\n',' '))
time.sleep(55); t=p.evaluate("()=>{const o=[...document.querySelectorAll('.popup-overlay')].pop();return o?o.innerText:''}"); c=re.findall(r'\d:\d\d',t)
note('55 vraies secondes plus tard, le compte à rebours du stylo vert a avancé',bool(c) and c[0] in ('1:08','1:07','1:06','1:05','1:04','1:03','1:02','1:01','1:00','1:09','1:10','1:11','1:12'),str(c[:1]))
fs=(b.lire(p,'correction_dictee/%s/autocorrection/%s/styloFin'%(DGD,EK)) or 0)
while now()<fs+3000: time.sleep(2)
ouvert=p.evaluate("()=>!![...document.querySelectorAll('button')].find(x=>x.textContent.includes('Répondre à une question')&&!x.textContent.includes('🔒'))")
note('à la fin des 2 vraies minutes de stylo vert : questions ouvertes',ouvert and not p.query_selector('.popup-overlay'))
note('à %d s de la fin, questions à faire : alerte rouge « Plus que 3 minutes » (pendant le stylo vert, la fenêtre la recouvre)'%((FIN-now())//1000),'Plus que 3 minutes.' in p.inner_text('body'))
while now()<FIN+4000: time.sleep(2)
t=p.inner_text('body').replace('\xa0',' ')
note('après la fin réelle de l’heure : questions fermées, plus d’alerte','L’heure est terminée : les questions sont fermées.' in t and 'Plus que' not in t)
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
log('BILAN TEMPS RÉEL : %s'%('TOUT PASSE' if all(bil) else 'ÉCHEC'))
