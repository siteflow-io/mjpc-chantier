"""Reproduire : passer de la correction classique au mode rapide et retour ; les erreurs restent-elles ? sont-elles enregistrées ?"""
import sys, copy, json, os; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F=os.environ.get('FICHIER','../live_0aeb.html'); D3='dictee_brevet_blanc_3e-3e_charles_de_gaulle'
b=Banc(F,1400,900); p=b.ouvrir('?mode=prof',db=copy.deepcopy(L.BASE)); p.wait_for_timeout(1000); dl=[]; p.on('dialog',lambda d: dl.append(d.message[:90]))
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('brevet blanc 3E')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1400)
p.evaluate("(n)=>{const x=[...document.querySelectorAll('*')].filter(e=>e.children.length===0&&e.textContent.trim()===n);(x[0].closest('button,[role=button],div[style*=cursor]')||x[0]).click()}",'C. Lzzub'); p.wait_for_timeout(900)
barre=lambda: p.evaluate("()=>document.body.innerText.slice(0,70).replace(/\\n/g,' ')")
def marque(i,t,f=None):
    p.evaluate("(i)=>document.querySelectorAll('.word-grid button.word-btn')[i].click()",i); p.wait_for_timeout(250)
    p.evaluate("(t)=>{const b=document.querySelector('.popup-btn-'+t.toLowerCase());b&&b.click()}",t); p.wait_for_timeout(250)
    if t in 'GL':
        p.evaluate("(v)=>{const i=[...document.querySelectorAll('.popup-overlay input')][0];if(!i)return;const d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;d.call(i,v);i.dispatchEvent(new Event('input',{bubbles:true}))}",f or 'xx'); p.wait_for_timeout(120); p.keyboard.press('Enter'); p.wait_for_timeout(250)
marque(3,'G','naturelement'); marque(7,'L','centr'); print('1. classique, 2 erreurs :',barre())
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Rapide'));b&&b.click()}"); p.wait_for_timeout(800)
print('2. après passage au mode rapide :',barre(),'| écran :',p.evaluate("()=>!!document.querySelector('.word-grid')"))
p.evaluate("()=>{const b=document.querySelector('.fast-btn.fast-m');b&&b.click()}"); p.wait_for_timeout(500)
print('3. une erreur « manquant » en mode rapide :',barre())
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Rapide')||x.textContent.includes('Classique')||x.textContent.includes('classique'));b&&b.click()}"); p.wait_for_timeout(800)
print('4. retour en classique :',barre())
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.startsWith('Enregistrer'));b&&b.click()}"); p.wait_for_timeout(1000)
r=b.lire(p,'correction_dictee/%s/results/czzalur_lzzub'%D3)
print('5. enregistré au hub :',None if not r else [(e['idx'],e['type'],e.get('fautif')) for e in (r.get('errors') or []) if e],'note',None if not r else r.get('note'))
print('   fenêtres :',dl)
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent==='←');b&&b.click()}"); p.wait_for_timeout(600)
p.evaluate("(n)=>{const x=[...document.querySelectorAll('*')].filter(e=>e.children.length===0&&e.textContent.trim()===n);(x[0].closest('button,[role=button],div[style*=cursor]')||x[0]).click()}",'C. Lzzub'); p.wait_for_timeout(900)
print('6. rouverte :',barre()); print('erreurs de page :',b.erreurs[:3]); b.fermer()
