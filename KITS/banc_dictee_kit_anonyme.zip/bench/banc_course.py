"""Un battement de présence tombe juste après une bonne réponse : le mot trouvé doit rester trouvé."""
import sys, copy; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; EK='bzzinet_azzet'
for nom,f in (('ancien (livraison 1)','../work_L1.html'),('nouveau','../work/correction_dictee.html')):
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None)
    b=Banc(f); errs=L.erreurs(DGD,EK); p=L.ouvrir(b,DGD,EK,db)
    sp=p.query_selector_all('span.word-btn[style*="cursor: pointer"]'); avant=len(sp); sp[0].click(); p.wait_for_timeout(150)
    p.fill('input[placeholder="Tape le mot correct…"]', errs[0]['word']); p.get_by_role('button', name='✓').click()
    p.wait_for_timeout(300)
    p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now())", 'correction_dictee/%s/autocorrection/%s/lastSeen'%(DGD,EK))   # le battement
    p.wait_for_timeout(2500)
    apres=len(p.query_selector_all('span.word-btn[style*="cursor: pointer"]'))
    fiche=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(DGD,EK)) or {}
    print('%-22s mots masqués : %d avant → %d après (attendu %d) ; trouvée au hub : %s ; %s'%(nom,avant,apres,avant-1,bool((fiche.get('results') or {}) and (fiche['results'][0] if isinstance(fiche['results'],list) else fiche['results'].get('0'))),'OK' if apres==avant-1 else 'KO'))
    b.fermer()
