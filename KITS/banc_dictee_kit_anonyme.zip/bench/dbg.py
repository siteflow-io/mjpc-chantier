import sys; sys.argv=['x','x','../work/correction_dictee.html']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
b=Banc('../work/correction_dictee.html',1536,864); p=b.ouvrir('?mode=prof'); p.wait_for_timeout(1000)
p.get_by_text('Ouvrir →').first.click(); p.wait_for_timeout(1500)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(500)
p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1500)
print(p.evaluate('''()=>{const t=[...document.querySelectorAll('table')].find(x=>x.textContent.includes('Note corr.'));const hs=[...t.querySelectorAll('th')].map(h=>h.textContent.trim());return [hs,[...t.querySelectorAll('tbody tr')].slice(0,4).map(r=>[...r.children].map(c=>c.textContent.trim()))]}'''))
b.fermer()
