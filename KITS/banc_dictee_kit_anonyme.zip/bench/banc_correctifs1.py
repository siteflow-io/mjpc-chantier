"""Correctifs du 29/09 (retours de classe) — par le geste."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
now=lambda:int(time.time()*1000)
U='dictee_5e_chapitre_utopie-5e_herge'; C='bzzetor_czzix'; Ly='czzilin_lzzal'
BU=L.BASE['correction_dictee'][U]; cl=L.classe_registre(BU['config']['classe'])
# 1. Candice a fini son autocorrection AVANT (sans stylo vert rangé), Lylou corrige à côté : la moitié de Candice se verrouille
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000
eC=L.erreurs(U,C); D['autocorrection'][C]={'attempts':{str(i):1 for i,e in enumerate(eC) if e.get('type')!='A'},'results':{str(i):True for i,e in enumerate(eC) if e.get('type')!='A'},'status':'done'}
D['autocorrection'][Ly]={'attestation':{'t':1},'sessionDebut':now()-5*60000}
ide=lambda k:{'identite':{'nom':L.nom_eleve(cl,k),'cle':k,'classe':cl,'via':'code'},'t':now(),'dictee':U}
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(700)
p.evaluate("(x)=>{localStorage.setItem('cd_places',JSON.stringify({n:2,t:Date.now()}));localStorage.setItem('cd_moitie_1',JSON.stringify(x[0]));localStorage.setItem('cd_moitie_2',JSON.stringify(x[1]))}",[ide(C),ide(Ly)]); p.reload(); p.wait_for_timeout(3200)
g=p.evaluate("()=>{const m=[...document.querySelectorAll('.moitie')];return {v:!!m[0].querySelector('.moitie-verrou'),corrige:m[0].innerText.includes('Ta dictée corrigée')&&!m[0].querySelector('.moitie-verrou')}}")
note('1. Candice (autocorrection finie avant) à côté de Lylou qui corrige : sa moitié est verrouillée',g['v'],str(g))
note('réseau élèves : 0 accès au vrai hub, 0 erreur',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:120]); b.fermer()
# 2. votre suivi : la fenêtre de fin d'heure se referme par « Plus tard »
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['heure']={'debut':now()-60*60000,'fin':now()-1000}
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('utopie')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1300)
avant='Fin de l’heure' in p.inner_text('body')
p.get_by_role('button',name='Plus tard').click(); p.wait_for_timeout(500); t=p.inner_text('body')
note('2. « Plus tard » referme la fenêtre ; la carte rouge garde +10 min et Clôturer',avant and 'Où en est la classe' not in t and 'L’heure est dépassée' in t and p.get_by_role('button',name='■ Clôturer l’heure').count()==1)
p.evaluate("()=>{const r=[...document.querySelectorAll('tbody tr')];r[3].click()}"); p.wait_for_timeout(700)
note('3. la fiche d’un élève s’ouvre sans que la fenêtre de fin d’heure revienne','Où en est la classe' not in p.inner_text('body'))
p.keyboard.press('Escape'); p.evaluate("()=>{const r=[...document.querySelectorAll('tbody tr')];r[3]&&r[3].click()}"); p.wait_for_timeout(300)
p.get_by_role('button',name='+10 min').first.click(); p.wait_for_timeout(500)
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/heure/fin'%U); p.wait_for_timeout(700)
note('4. l’heure prolongée puis de nouveau dépassée : la fenêtre revient','Où en est la classe' in p.inner_text('body'))
note('réseau professeur : 0 accès au vrai hub, 0 erreur',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:120]); b.fermer()
# 5. plus de bandeau rouge après 2 minutes sans geste (on attend vraiment 2 min 35 s)
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000; D['autocorrection'].pop(Ly,None)
b=Banc(F,900,900); p=L.ouvrir(b,U,Ly,db); p.wait_for_timeout(155000)
st=b.lire(p,'correction_dictee/%s/autocorrection/%s/status'%(U,Ly))
note('5. 2 min 35 s sans geste : aucun bandeau rouge chez l’élève, votre suivi le voit « inactif »','Reprends le travail' not in p.inner_text('body') and st=='idle',str(st)); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
