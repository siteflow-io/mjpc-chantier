"""Banc du lot 1c-1, par le geste, avant (1b) / après."""
import sys, copy; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
AV='../work_1b.html'; AP='../work/correction_dictee.html'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
def db0():
    return copy.deepcopy(L.BASE)
# 1. « À savoir » et note de dictée à la française (élève à note non entière)
cand=None
for did,D in L.BASE['correction_dictee'].items():
    for ek,r in (D.get('results') or {}).items():
        if isinstance(r.get('note'),float) and r['note']%1 and D['config'].get('showNote')!=False and L.nom_eleve(L.classe_registre(D['config'].get('classe','')),ek):
            e=L.erreurs(did,ek)
            if 1<=len([x for x in e if x.get('type')!='A'])<=6: cand=(did,ek); break
    if cand: break
did,ek=cand; errs=L.erreurs(did,ek); N=len([x for x in errs if x.get('type')!='A'])
for nom,f in (('avant',AV),('après',AP)):
    db=db0(); D=db['correction_dictee'][did]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000; D['autocorrection'].pop(ek,None); D['config']['showNote']=True
    b=Banc(f); p=L.ouvrir(b,did,ek,db); L.jouer(p,errs,{i:(1 if k==0 else 0) for k,i in enumerate([i for i,x in enumerate(errs) if x.get('type')!='A'])}); p.wait_for_timeout(800)
    t=p.evaluate("()=>{const x=[...document.querySelectorAll('div')].find(e=>e.textContent.startsWith('À savoir')&&e.children.length<=2);return x?x.textContent:''}")
    n10=p.evaluate("()=>{const x=[...document.querySelectorAll('div')].find(e=>e.children.length===0&&/^\\d+([.,]\\d+)?\\/\\d+$/.test(e.textContent.trim())&&!e.textContent.includes('/5'));return x?x.textContent:''}")
    print('   %s — note de dictée affichée « %s » ; À savoir : %s'%(nom,n10,t[:230]))
    if nom=='après':
        cout=str(round(5/N+1e-9,2)).replace('.',',')
        ok=(',' in n10) and ('tu avais %d erreur'%N in t) and ('coûté %s point'%cout in t) and ('le premier était offert' in t)
        note('1. « À savoir » avec ses chiffres et note de dictée à la française (%s, N=%d)'%(ek,N),ok)
    b.fermer()
# 2. un lien vers une dictée dépubliée
for nom,f in (('avant',AV),('après',AP)):
    db=db0(); D=db['correction_dictee'][did]; D['config']['published']=False; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000
    b=Banc(f); p=L.ouvrir(b,did,ek,db); p.wait_for_timeout(800)
    masques=len(p.query_selector_all('span.word-btn[style*="cursor: pointer"]')); corps=p.inner_text('body')
    ouverte=masques>0 or 'Bravo' in corps or 'Note de départ' in corps
    print('   %s — lien vers la dictée dépubliée : %s'%(nom,'la dictée s’ouvre' if ouverte else 'refusée : '+('message présent' if 'plus disponible' in corps else 'sans message')))
    if nom=='après': note('2. une dictée dépubliée ne s’ouvre plus par lien, message affiché',(not ouverte) and 'plus disponible' in corps)
    b.fermer()
# 3. connexion : prénom composé et accents
for nom,f in (('avant',AV),('après',AP)):
    res={}
    for cas,(nm,pr) in (('prénom composé',('DUPONT','Marie Lou')),('sans accent',('DZZILUB','Noemie'))):
        db=db0(); db['classes']['_banc']={'eleves':['DUPONT Marie Lou'],'niveau':'5e'}
        b=Banc(f); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(1000)
        p.fill('input[placeholder="1234"]','0000'); p.fill('input[placeholder="DUPONT"]',nm); p.fill('input[placeholder="Marie"]',pr); p.get_by_role('button',name='Entrer').click(); p.wait_for_timeout(900)
        msg=p.evaluate("()=>{const x=[...document.querySelectorAll('p')].find(e=>/code|élève à ce nom/i.test(e.textContent)&&getComputedStyle(e).color.includes('197'));return x?x.textContent:''}") or p.inner_text('body')[-160:]
        res[cas]=msg; b.fermer()
    print('   %s — %s'%(nom,' | '.join('%s : %s'%(k,v[:70]) for k,v in res.items())))
    if nom=='après': note('3. nom reconnu malgré prénom composé et accent (le code est ensuite demandé)', all('nom' not in v.lower() or 'code' in v.lower() for v in res.values()) and all('Aucun élève' not in v for v in res.values()))
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
