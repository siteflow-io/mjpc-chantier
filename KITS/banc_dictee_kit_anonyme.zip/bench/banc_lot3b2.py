"""Banc du lot 3b (clavier dessiné) — par le geste : chaque lettre est une touche touchée."""
import sys, copy, json, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000
cl=L.classe_registre(D['config']['classe']); A=('bzzinet_azzet',L.nom_eleve(cl,'bzzinet_azzet'))
D['autocorrection'].pop(A[0],None); D['autocorrection'][A[0]]={'attestation':{'t':1}}
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(800)
p.evaluate("(a)=>{localStorage.setItem('cd_places',JSON.stringify({n:2,t:Date.now()}));localStorage.setItem('cd_moitie_1',JSON.stringify({identite:{nom:a[0],cle:a[1],classe:a[2],via:'code'},t:Date.now()}))}",[A[1],A[0],cl]); p.reload(); p.wait_for_timeout(1600)
def touches(moitie,texte):
    for ch in texte:
        lab='espace' if ch==' ' else ch
        ok=p.evaluate("(a)=>{const m=document.querySelectorAll('.moitie')[a[0]];const b=[...m.querySelectorAll('button')].find(x=>x.textContent===a[1]||x.textContent===a[1].toLowerCase()&&a[2]);if(!b)return false;b.click();return true}",[moitie,lab,False])
        if not ok: return 'touche absente : '+lab
        p.wait_for_timeout(40)
    return ''
# 1. connexion à droite au clavier dessiné
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[1];const b=[...m.querySelectorAll('button')].find(x=>x.textContent.includes('Pas là ?'));if(b)b.click()}"); p.wait_for_timeout(400)   # le binôme proposé : on choisit le formulaire complet
m=1; t=p.evaluate("()=>document.querySelectorAll('.moitie')[1].innerText")
note('1. connexion : pavé de chiffres pour le code',all(('\n%s\n'%c) in ('\n'+t+'\n') or c in t for c in '0123456789') and 'Mon code' in t)
e=touches(1,'1234'); p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[1];[...m.querySelectorAll('button')].find(x=>x.textContent==='✓').click()}"); p.wait_for_timeout(200)
e+=touches(1,'davy'); p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[1];m.querySelectorAll('input')[2].focus()}"); p.wait_for_timeout(150)
e+=touches(1,'no'); e+=touches(1,'é'); e+=touches(1,'mie')
vals=p.evaluate("()=>[...document.querySelectorAll('.moitie')[1].querySelectorAll('input')].map(i=>i.value)")
note('2. les touches remplissent le code, le nom, le prénom (accent compris)',vals==['1234','davy','noémie'],str(vals)+' '+e)
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[1];[...m.querySelectorAll('button')].find(x=>x.textContent==='Entrer').click()}"); p.wait_for_timeout(900)
t=p.evaluate("()=>document.querySelectorAll('.moitie')[1].innerText")
note('3. « Entrer » : le nom est reconnu, l’app passe à la vérification du code','Aucun élève' not in t and ('code' in t.lower()),t[-120:].replace('\n',' | '))
# 4. à gauche, corriger un mot au clavier dessiné
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];const cartes=[...m.querySelectorAll('div')].filter(x=>x.textContent.includes('grandes découvertes')&&x.textContent.includes('Ouvrir')&&x.children.length<8);const c=cartes[cartes.length-1];const b=[...c.querySelectorAll('button,span,div')].find(x=>x.textContent.trim().startsWith('Ouvrir'));(b||c).click()}"); p.wait_for_timeout(1400)
avant=p.evaluate("()=>document.querySelectorAll('.moitie')[0].querySelectorAll('span.word-btn[data-err]').length")
p.evaluate("()=>document.querySelectorAll('.moitie')[0].querySelector('span.word-btn[data-err=\"0\"]').click()"); p.wait_for_timeout(600)
g=p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];const mr=m.getBoundingClientRect();const f=[...m.querySelectorAll('div')].find(x=>x.style&&x.style.position==='fixed'&&x.textContent.includes('Erreur n°'));const w=m.querySelector('span.word-btn[data-err=\"0\"]').getBoundingClientRect();if(!f)return null;const r=f.getBoundingClientRect();return {dans:r.left>=mr.left-1&&r.right<=mr.right+1,enBas:Math.abs(r.bottom-mr.bottom)<=2,motAuDessus:w.bottom<=r.top,natif:!!m.querySelector('input:focus')}}")
note('4. la feuille du clavier s’ouvre dans la moitié gauche, le mot au-dessus, sans clavier de la tablette',bool(g) and g['dans'] and g['enBas'] and g['motAuDessus'] and not g['natif'],str(g))
e=touches(0,'échanger'); p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('button')].find(x=>x.textContent==='✓ Valider').click()}"); p.wait_for_timeout(1700)
apres=p.evaluate("()=>document.querySelectorAll('.moitie')[0].querySelectorAll('span.word-btn[data-err]').length")
note('5. « échanger » tapé touche par touche puis validé : le mot est trouvé',apres==avant-1 and not e,'%d → %d %s'%(avant,apres,e))
# 6. des lettres tapées survivent à un rechargement
p.evaluate("()=>document.querySelectorAll('.moitie')[0].querySelector('span.word-btn[data-err=\"2\"]').click()"); p.wait_for_timeout(500)
touches(0,'regag'); p.reload(); p.wait_for_timeout(2200)
v=p.evaluate("()=>{const x=document.querySelectorAll('.moitie')[0].querySelector('.saisie-moitie');return x?x.textContent:null}")
note('6. après rechargement : la feuille rouverte avec « regag »',v=='regag',str(v))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
