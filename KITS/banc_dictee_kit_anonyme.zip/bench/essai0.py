import sys; sys.path.insert(0,'.')
from banc import Banc
b=Banc('../livre.html')
p=b.ouvrir('?mode=eleve', session={'display':'CZZUBET Lzzam','classe':'4E BANKSY'})
p.wait_for_timeout(1500)
p.screenshot(path='cap/e0_liste.png', full_page=False)
print(p.inner_text('body')[:900])
print('violations',b.violations,'bloqués',b.bloques[:5],'erreurs',b.erreurs[:3])
b.fermer()
