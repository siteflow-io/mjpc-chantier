"""Correctifs 2 — la fenêtre de fin d'heure reste dans votre pilotage ; « où en est la classe » sur les vraies données de Hergé."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; bilan=[]; now=lambda:int(time.time()*1000)
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
U='dictee_5e_chapitre_utopie-5e_herge'
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['heure']={'debut':now()-50*60000,'fin':now()+90000}
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('utopie')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1300)
p.evaluate("()=>{const r=[...document.querySelectorAll('tbody tr')].find(x=>x.textContent.includes('Lylou'));r.click()}"); p.wait_for_timeout(700)
vue=p.evaluate("()=>document.body.innerText.includes('VUE ÉLÈVE')||document.body.innerText.includes('Vue élève')||document.body.innerText.includes('JOURNAL DES ESSAIS')||document.body.innerText.includes('Journal des essais')")
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/heure/fin'%U); p.wait_for_timeout(900)
t=p.inner_text('body')
note('1. l’heure se termine pendant que vous regardez Lylou : la fenêtre ne recouvre pas sa vue',vue and 'Où en est la classe' not in t,str(vue))
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Fermer'));b&&b.click()}"); p.wait_for_timeout(800)
t=p.inner_text('body')
note('2. revenu au suivi : la fenêtre « Fin de l’heure » s’y affiche','Où en est la classe' in t)
import re
m=re.search(r'Où en est la classe : (\d+) (?:ont|a) fini · (\d+) (?:répondent|répond) à leurs questions · (\d+)',t)
note('3. vraies données de Hergé (autocorrections de l’an dernier) : personne ne « répond à ses questions »',bool(m) and m.group(2)=='0',m.group(0) if m else t[:200])
note('réseau : 0 accès au vrai hub, 0 erreur',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:120]); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
