import sys,json; sys.path.insert(0,'.')
from banc import Banc, instantane
db=instantane()
D='dictee_preparee_5e_grandes_decouvertes-5e_herge'
db['correction_dictee'][D]['autocorrection'].pop('bzzinet_azzet',None)
db['correction_dictee'][D]['copyPublishedAt']=1790000000000
b=Banc('../work/correction_dictee.html')
p=b.ouvrir('?mode=eleve&dictee='+D, db=db, session={'display':'BZZINET Azzet','classe':'5e HERGÉ'})
p.wait_for_timeout(1500)
print(p.inner_text('body')[:200])
sp=p.query_selector_all('span[style*="cursor: pointer"]')
for s in sp[:3]: print(s.evaluate('e=>e.outerHTML')[:400])
errs=db['correction_dictee'][D]['results']['bzzinet_azzet']['errors']
print(json.dumps(errs,ensure_ascii=False))
