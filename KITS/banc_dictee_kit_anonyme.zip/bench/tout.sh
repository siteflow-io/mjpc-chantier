#!/bin/sh
# Banc unique : rejoue tous les bancs du chantier d'une seule commande ; échoue si un seul échoue.
# Usage : sh tout.sh ../work/correction_dictee.html
F=${1:-../work/correction_dictee.html}; KO=0
run(){ echo "== $1"; shift; "$@" 2>&1 | grep -E "^OK|^KO|BILAN" ; [ "${PIPESTATUS:-0}" = "0" ] || true; }
for b in banc_lot1c2.py banc_lot2a.py banc_lot2b.py banc_lot2c.py banc_lot2d.py banc_lot1b.py banc_lot3a.py banc_lot3b.py banc_lot3b2.py banc_lot3c.py banc_lot3d.py banc_lot3d2.py; do
  echo "== $b"; python3 -u $b > /tmp/sortie_$b.txt 2>&1; grep -E "^OK|^KO|BILAN" /tmp/sortie_$b.txt; grep -q "BILAN : TOUT PASSE" /tmp/sortie_$b.txt || KO=1
done
echo "== suivi (142 fiches)"; PARTIE=A python3 -u banc_lot1.py $F > /tmp/s_A.txt 2>&1; grep -E "^OK|^KO" /tmp/s_A.txt; grep -q "^KO" /tmp/s_A.txt && KO=1
echo "== sessions élèves"; PARTIE=B NB=12 python3 -u banc_lot1.py $F > /tmp/s_B.txt 2>&1; grep -E "B\. " /tmp/s_B.txt; grep -q "^KO" /tmp/s_B.txt && KO=1
echo "== fiche (livraison 1)"; FORMULE=a6 SANS_SCENARIOS=1 TERMINER=1 python3 -u banc_L1.py ../livre.html $F 71 12 > /tmp/s_L1.txt 2>&1; grep BILAN /tmp/s_L1.txt; grep -q "TOUT PASSE" /tmp/s_L1.txt || KO=1
echo "== signal de présence"; python3 banc_course.py 2>&1 | tail -1 | tee /tmp/s_c.txt; grep -q "nouveau.*OK" /tmp/s_c.txt || KO=1
[ $KO = 0 ] && echo "BANC UNIQUE : TOUT PASSE" || { echo "BANC UNIQUE : ÉCHEC"; exit 1; }
