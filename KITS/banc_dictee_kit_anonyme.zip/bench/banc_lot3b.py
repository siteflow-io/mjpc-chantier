"""Banc du lot 3b — la tablette en deux moitiés, par le geste."""
import sys, copy, json, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000
cl=L.classe_registre(D['config']['classe'])
A=('bzzinet_azzet',L.nom_eleve(cl,'bzzinet_azzet')); N=('dzzilub_nzzov',L.nom_eleve(cl,'dzzilub_nzzov'))
for k,_ in (A,N): D['autocorrection'].pop(k,None)
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(1000)
note('1. écran large : « Combien êtes-vous sur cette tablette ? »','Combien êtes-vous sur cette tablette ?' in p.inner_text('body'))
p.get_by_role('button',name='👥 2 élèves').click(); p.wait_for_timeout(900)
m=p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(x=>{const r=x.getBoundingClientRect();return [Math.round(r.left),Math.round(r.width),x.innerText.includes('Entre ton code personnel')]})")
note('2. deux moitiés côte à côte, chacune sur sa connexion',len(m)==2 and all(x[2] for x in m) and m[1][0]>=m[0][1]-10,str(m))
# reprise après rechargement : chaque moitié retrouve son élève
p.evaluate("(a)=>{localStorage.setItem('cd_moitie_1',JSON.stringify({identite:{nom:a[0][1],cle:a[0][0],classe:a[2],via:'code'},t:Date.now()}));localStorage.setItem('cd_moitie_2',JSON.stringify({identite:{nom:a[1][1],cle:a[1][0],classe:a[2],via:'code'},t:Date.now()}))}",[list(A),list(N),cl])
p.reload(); p.wait_for_timeout(1600)
t=p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(x=>x.innerText)")
note('3. après rechargement : pas de question redemandée, chaque moitié retrouve son élève sans code',len(t)==2 and 'Mes dictées' in t[0] and A[1] in t[0] and 'Mes dictées' in t[1] and N[1] in t[1])
# la moitié gauche ouvre sa dictée ; la droite ne bouge pas
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];const cartes=[...m.querySelectorAll('div')].filter(x=>x.textContent.includes('grandes découvertes')&&x.textContent.includes('Ouvrir')&&x.children.length<8);const c=cartes[cartes.length-1];const b=[...c.querySelectorAll('button,span,div')].find(x=>x.textContent.trim().startsWith('Ouvrir'));(b||c).click()}"); p.wait_for_timeout(1300)
if p.evaluate("()=>document.querySelectorAll('.moitie')[0].innerText.includes('J’ai lu et compris')"):
    p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('label')].find(l=>l.textContent.includes('J’ai lu et compris')).click()}"); p.wait_for_timeout(200)
    p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('button')].find(b=>b.textContent.includes('Commencer mon autocorrection')).click()}"); p.wait_for_timeout(900)
t=p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(x=>x.innerText)")
note('4. la moitié gauche corrige, la droite reste sur sa liste','Note de départ' in t[0] and 'Mes dictées' in t[1])
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];m.querySelector('span.word-btn[style*=\"cursor: pointer\"]').click()}"); p.wait_for_timeout(500)
r=p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];const mr=m.getBoundingClientRect();const f=[...m.querySelectorAll('div')].find(x=>x.style&&x.style.position==='fixed'&&x.textContent.includes('Erreur n°'));if(!f)return null;const o=f.getBoundingClientRect();return [Math.round(mr.left),Math.round(mr.right),Math.round(o.left),Math.round(o.right),Math.round(mr.bottom),Math.round(o.bottom)]}")
note('5. la saisie s’ouvre dans la moitié gauche, calée en bas de la moitié',bool(r) and r[2]>=r[0]-1 and r[3]<=r[1]+1 and abs(r[4]-r[5])<=2,str(r))
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[0];[...m.querySelectorAll('button')].find(x=>x.textContent==='✕').click()}"); p.wait_for_timeout(200)
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[1];[...m.querySelectorAll('button')].find(b=>b.textContent.includes('Me déconnecter')).click()}"); p.wait_for_timeout(700)
ls=p.evaluate("()=>[localStorage.getItem('cd_moitie_1')!==null,localStorage.getItem('cd_moitie_2')!==null]")
t=p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(x=>x.innerText)")
note('6. « Me déconnecter » à droite : seule la moitié droite repart à la connexion',ls==[True,False] and ('Entre ton code personnel' in t[1] or 'tape ton code' in t[1]) and 'Note de départ' in t[0],str(ls))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
# écran étroit et lien direct : pas de question
b=Banc(F,800,900); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(900)
note('7. écran étroit (téléphone) : pas de question, app normale','Combien êtes-vous' not in p.inner_text('body') and 'Entre ton code personnel' in p.inner_text('body')); b.fermer()
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve&dictee='+DGD,db=db); p.wait_for_timeout(900)
note('8. lien direct (maison) : pas de question','Combien êtes-vous' not in p.inner_text('body')); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
