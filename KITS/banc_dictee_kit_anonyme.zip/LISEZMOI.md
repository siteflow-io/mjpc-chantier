# Kit de bancs — correction_dictee — VERSION ANONYMISÉE DÉPOSÉE AU SAS (conscience n°12, 01/10/2026)

Ce kit est celui remis par Paul le 01/10 (md5 d'origine 62b94362ea30b28074d7a02a69ae267a), **anonymisé** pour le sas :
les 125 noms d'élèves de l'instantané (`root/`) et des bancs sont remplacés par des noms impossibles, initiales conservées
(« NOM Prénom » → « NZZxxxx Pzzxx », clé `sanMJPC` remplacée de même partout) ; le commentaire du code qui portait un nom réel
est reformulé dans les copies HTML. Conséquence mesurée : `scenarios_grille.py` trouve 2 élèves « CL » (3 à l'origine).
`live_663.html` = la 6.6.3 en ligne (737 047 o, md5 be6e2481…) avec ce commentaire reformulé ; `work/correction_dictee.html` idem.
Rejoués après anonymisation : `scenarios_modes.py` (S1/S3 perte, S2 correct), `scenarios_grille.py`, `fuzz_correction.py` (NB=1).


Fichier visé : `work/correction_dictee.html` = la version EN LIGNE mesurée le 01/10/2026 à 13 h 10
(738 095 octets, md5 0aeb77123b356a2529dbe3751a3911c6). `live_0aeb.html` en est une copie témoin.
Aucun banc ne touche le vrai hub : un faux hub (`bench/fakefb.js`) est servi avec un instantané (`root/`, 27/09/2026).
Chaque banc vérifie « 0 accès au vrai hub, 0 erreur de page ».

Prérequis : python3, playwright (chromium). Tout se lance depuis `bench/`.

## Bugs de la correction (à reproduire, puis à rejouer après réparation)
- `python3 scenarios_modes.py`
  - S1 : mode texte, 2 erreurs, retour à la grille sans « Enregistrer » → AUJOURD'HUI : rouverte « 10 … · · −0 », hub [] (perte silencieuse).
    ATTENDU après réparation : les 2 erreurs retrouvées (ou demande explicite avant de quitter, selon la décision de Paul).
  - S2 : mode rapide → « ⏸ Pause » → mode texte → « Enregistrer » : déjà correct, doit le rester.
  - S3 : mode texte, 2 erreurs non enregistrées, puis ⇧R → AUJOURD'HUI : « 0 err. », hub []. ATTENDU : « 2 err. », rien de perdu.
- `python3 bug_modes.py` : même famille (variante avec le bouton).

## Non-régression de la correction (doivent rester à 0 bug)
- `NB=5 GRAINE=1 python3 fuzz_correction.py` puis `NB=4 GRAINE=2 …` : mode texte, deux passes par copie (neuve puis reprise),
  modèle tenu à part, comparé au hub après « Enregistrer » et à l'écran après réouverture.
- `NB=3 GRAINE=2 python3 fuzz_rapide.py` : mode rapide au clavier, hub comparé au modèle après CHAQUE touche.
- `python3 scenarios_grille.py` : absent sur copie existante, Recalculer, M→P, recherche par initiales.

## Non-régression du chantier (élève, tablette, suivi) — voir les en-têtes de chaque fichier
banc_lot1c2, banc_lot2a, banc_lot2b, banc_lot2c, banc_lot2d, banc_lot3a, banc_lot3b, banc_lot3b2, banc_lot3c,
banc_lot3d, banc_lot3d2, banc_gardes, banc_complement, banc_textes295, banc_correctifs1, banc_correctifs2,
e2e_A (BAREME=preparee|brevet), e2e_BC, e2e_D, fuzz_mega (FAMILLE=F1|F2|F3|F5), reel_heure (heure réelle, ~4 min 40),
`PARTIE=A python3 banc_lot1.py ../work/correction_dictee.html` (142 notes du suivi), banc_course.
`tout.sh` les enchaîne (une commande peut dépasser 5 min selon l'environnement).
Note : `BANC_SECURISE=1` sert l'app depuis http://localhost (origine sécurisée) pour la vraie vérification des codes chiffrés.
