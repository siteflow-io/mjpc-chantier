"""Banc du lot 3d (2/2) — la vue en direct, par le geste."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
now=lambda:int(time.time()*1000)
A='bzzinet_azzet'; PA='vzzetek_lzzin'; errs=L.erreurs(DGD,A)
# 1. l'élève tape : son écran part au hub
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(A,None)
b=Banc(F,900,900); p=L.ouvrir(b,DGD,A,db)
p.query_selector_all('span.word-btn[style*="cursor: pointer"]')[2].click(); p.wait_for_timeout(300)
p.fill('input[placeholder="Tape le mot correct…"]','regag'); p.wait_for_timeout(900)
dr=b.lire(p,'correction_dictee/%s/autocorrection/%s/direct'%(DGD,A)) or {}
note('1. l’élève tape « regag » : le mot ouvert et ses lettres sont au hub',dr.get('frappe')=='regag' and dr.get('err') is not None,str(dr))
b.fermer()
# 2. votre suivi : la vue en direct du binôme
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000
D['autocorrection'][A]={'attestation':{'t':1},'sessionDebut':now()-5*60000,'attempts':{'0':1},'results':{'0':True},'status':'active','lastSeen':now(),'direct':{'err':2,'frappe':'regag','fin':False,'t':now()}}
D['autocorrection'][PA]={'attestation':{'t':1},'sessionDebut':now()-5*60000,'status':'active','lastSeen':now()}
D['binomes']={A:PA,PA:A}; cl=L.classe_registre(D['config']['classe'])
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('grandes')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1500)
p.evaluate("(n)=>{const t=[...document.querySelectorAll('table')].find(x=>x.textContent.includes('Note corr.'));const hs=[...t.querySelectorAll('th')].map(h=>h.textContent.trim());const j=hs.indexOf('Élève'),d=hs.indexOf('Direct');const r=[...t.querySelectorAll('tbody tr')].find(r=>r.children[j].textContent.trim()===n);r.children[d].querySelector('button').click()}",'B. Azzet'); p.wait_for_timeout(700)
t=p.evaluate("()=>{const o=[...document.querySelectorAll('.popup-overlay')].find(x=>x.textContent.includes('En direct'));return o?o.innerText:''}").replace('\xa0',' ')
nA=L.nom_eleve(cl,A); nP=L.nom_eleve(cl,PA)
note('2. 👁 ouvre « En direct — %s et %s »'%(nA,nP),('En direct — %s et %s'%(nA,nP)) in t)
note('3. on y lit le mot en cours et ses lettres, et le mot déjà trouvé','En train d’écrire l’erreur n°3 : « regag »' in t and 'regag|' in t and (errs[0]['word']+' ✓') in t)
p.evaluate("(c)=>window.__FAKE_DB_SET__(c,'regagnè')",'correction_dictee/%s/autocorrection/%s/direct/frappe'%(DGD,A)); p.wait_for_timeout(600)
t=p.evaluate("()=>{const o=[...document.querySelectorAll('.popup-overlay')].find(x=>x.textContent.includes('En direct'));return o?o.innerText:''}")
note('4. l’élève tape une lettre de plus : la vue suit sans rien toucher','regagnè|' in t)
w=[l['path'] for l in b.log(p) if 'autocorrection' in l['path']]
note('5. regarder ne change rien chez l’élève : aucune écriture dans sa fiche',not [x for x in w if A in x or PA in x],str(w[:3]))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
