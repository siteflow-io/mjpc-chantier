"""Banc du lot 2c — attestation, titre et phrase, tableau exact, par le geste."""
import sys, copy, json, math, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; EK='bzzinet_azzet'; errs=L.erreurs(DGD,EK)
# 1. l'attestation, avant tout
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None)
cl=L.classe_registre(D['config']['classe']); nom=L.nom_eleve(cl,EK)
b=Banc(F,900,900); p=b.ouvrir('?mode=eleve&dictee='+DGD,db=db,session={'display':nom,'classe':cl}); p.wait_for_timeout(1300)
t=p.inner_text('body'); dis=p.evaluate("()=>[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Commencer mon autocorrection')).disabled")
note('1. attestation : les cinq phrases, la case, le bouton inactif tant que rien n’est coché','Avant de commencer, Amauri' in t and 'Si ton voisin t’aide, c’est toi qui tapes.' in t and dis and not p.query_selector('span.word-btn[style*="cursor: pointer"]'))
p.get_by_text('J’ai lu et compris').click(); p.get_by_role('button',name='Commencer mon autocorrection').click(); p.wait_for_timeout(700)
at=b.lire(p,'correction_dictee/%s/autocorrection/%s/attestation'%(DGD,EK))
note('2. cochée : rangée dans la fiche avec l’heure, et le texte apparaît',bool(at and at.get('t')) and len(p.query_selector_all('span.word-btn[style*="cursor: pointer"]'))>0)
L.jouer(p,errs,{i:0 for i,e in enumerate(errs) if e.get('type')!='A'}); p.wait_for_timeout(900)
t=p.inner_text('body').replace('\xa0',' ')
note('3. page de fin : titre de la tranche, phrase croisée, ligne d’attestation','Autocorrection parfaite, Amauri.' in t and 'Tu as lu et compris les consignes le' in t)
b.fermer()
# 4. rouvrir : l'attestation n'est pas redemandée
db2=copy.deepcopy(db); db2['correction_dictee'][DGD]['autocorrection'][EK]={'attestation':{'t':1},'sessionDebut':int(time.time()*1000)}
b=Banc(F,900,900); p=b.ouvrir('?mode=eleve&dictee='+DGD,db=db2,session={'display':nom,'classe':cl}); p.wait_for_timeout(1300)
note('4. déjà cochée : pas redemandée','J’ai lu et compris' not in p.inner_text('body')); b.fermer()
# 5. tableau exact : total affiché = déduction enregistrée, sur des élèves de chaque barème
cands=[]
for did,Dx in L.BASE['correction_dictee'].items():
    clx=L.classe_registre((Dx.get('config') or {}).get('classe',''))
    for ek,r in (Dx.get('results') or {}).items():
        e=L.erreurs(did,ek)
        if clx and L.nom_eleve(clx,ek) and 1<=len([x for x in e if x.get('type')!='A'])<=5: cands.append((did,ek))
import random; random.Random(7).shuffle(cands)
pieges=[]
for did,Dx in L.BASE['correction_dictee'].items():
    if (Dx.get('config') or {}).get('bareme')!='brevet': continue
    clx=L.classe_registre(Dx['config'].get('classe',''))
    for ek in (Dx.get('results') or {}):
        e=L.erreurs(did,ek)
        if clx and L.nom_eleve(clx,ek) and len([x for x in e if x.get('type')!='A'])<=12 and any(x.get('type') in ('P','M','I') for x in e): pieges.append((did,ek))
ko=[]; vus=0; baremes=set()
for did,ek in pieges[:6]+cands[:4]:
    dbx=copy.deepcopy(L.BASE); Dx=dbx['correction_dictee'][did]; Dx['copyPublishedAt']=Dx.get('copyPublishedAt') or 1790000000000; Dx['autocorrection'].pop(ek,None); Dx['config']['showNote']=True
    ee=L.erreurs(did,ek); bx=Banc(F,900,900); px=L.ouvrir(bx,did,ek,dbx); L.jouer(px,ee,{i:0 for i,e in enumerate(ee) if e.get('type')!='A'}); px.wait_for_timeout(900)
    px.evaluate("(c)=>window.__FAKE_DB_SET__(c, 0)",'correction_dictee/%s/autocorrection/%s/styloFin'%(did,ek)); px.wait_for_timeout(600)
    tt=px.inner_text('body').replace('\xa0',' ')
    ded=L.BASE['correction_dictee'][did]['results'][ek].get('deduction'); base=Dx['config'].get('base',20); nt=L.BASE['correction_dictee'][did]['results'][ek].get('note')
    fr=lambda x: (str(x)[:-2] if str(x).endswith('.0') else str(x)).replace('.',',')
    attendu='Barème : %s − %s = %s'%(fr(float(base)) if base%1 else str(base),fr(float(ded)),fr(float(max(0,round(base-ded,1)))))
    baremes.add(Dx['config'].get('bareme','preparee')); vus+=1
    if attendu not in tt: ko.append('%s/%s : attendu « %s »'%(did[:18],ek,attendu))
    bx.fermer()
note('5. tableau : la ligne « Barème » refait exactement la note enregistrée (%d élèves, barèmes %s)'%(vus,','.join(sorted(baremes))),not ko,'; '.join(ko[:3]))
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
