"""Banc du lot 1a — la note d'autocorrection, par le geste.
A. Votre suivi : pour chaque dictée, la colonne « Note corr. » et la vue détaillée, comparées au calcul exact.
B. L'écran élève : sessions au hasard ; note affichée pendant la correction, sur la page de fin, et note enregistrée.
C. La phrase de consigne : coût d'un raté pour cet élève."""
import sys, os, json, math, random, copy
sys.argv = sys.argv[:1] + ['x', sys.argv[1] if len(sys.argv) > 1 else '../work/correction_dictee.html']
os.environ['FORMULE'] = 'a6'
import banc_L1 as L
from banc import Banc
F = sys.argv[2]
def exact(N, rates):
    c = max(0, rates - 1); x = 5.0 if N <= 0 else max(0.0, 5 * (N - min(c, N)) / N)
    return math.floor(x * 100 + 0.5) / 100
def fr(v):
    t = repr(float(v)); t = t[:-2] if t.endswith('.0') else t
    return t.replace('.', ',')
def rates_de(ac):
    A = ac.get('attempts') or {}; R = ac.get('results') or {}
    A = A if isinstance(A, dict) else {str(i): v for i, v in enumerate(A) if v is not None}
    R = R if isinstance(R, dict) else {str(i): v for i, v in enumerate(R) if v is not None}
    return sum((max(0, (v or 0) - 1) if R.get(k) else (v or 0)) for k, v in A.items())
bilan = []
def note(nom, ok, det=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ') + nom + ('  — ' + det if det else ''), flush=True)
# ---------- A. le suivi ----------
if os.environ.get('PARTIE', 'AB') in ('A', 'AB'):
    b = Banc(F, 1536, 864)
    titres = {did: (d.get('config') or {}).get('title', '') for did, d in L.BASE['correction_dictee'].items()}
    tot = bons = 0; ecarts = []
    for did, d in L.BASE['correction_dictee'].items():
        if not d.get('autocorrection') or did == 'dictee_test_en_attente': continue
        p = b.ouvrir('?mode=prof'); p.wait_for_timeout(1000)
        cartes = p.query_selector_all('text=Ouvrir →')
        # ouvrir la bonne dictée : la carte dont le titre correspond
        ok_open = p.evaluate('''(a)=>{const t=a[0],k=a[1];const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes(t)&&x.textContent.includes(k)&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];if(!c)return false;const bt=[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir'));if(!bt)return false;bt.click();return true}''', [titres[did], (d.get('config') or {}).get('classe','')])
        p.wait_for_timeout(1500)
        p.get_by_role('button', name='Données').first.click(); p.wait_for_timeout(500)
        p.get_by_role('button', name='Suivi 🟢').first.click(); p.wait_for_timeout(1500)
        lignes = p.evaluate('''()=>{const t=[...document.querySelectorAll('table')].find(x=>x.textContent.includes('Note corr.'));if(!t)return null;
          const hs=[...t.querySelectorAll('th')].map(h=>h.textContent.trim());const i=hs.indexOf('Note corr.');const j=hs.indexOf('Élève');
          return [...t.querySelectorAll('tbody tr')].map(r=>{const c=[...r.children];return [c[j]?c[j].textContent.trim():'',c[i]?c[i].textContent.trim():'']})}''')
        if lignes is None: note('A ' + did[:30] + ' — tableau du suivi introuvable', False); continue
        ac = d.get('autocorrection') or {}; res = d.get('results') or {}
        if os.environ.get('DBG'): print('   DBG', did[:24], ok_open, lignes[:3]); 
        for ek, a in ac.items():
            if not isinstance(a, dict) or ('attempts' not in a and a.get('score') is None): continue
            N = len([e for e in L.erreurs(did, ek) if e.get('type') != 'A']) if ek in res else (a.get('total') or 0)
            attendu = fr(exact(N or 0, rates_de(a))) + '/5'
            nom = L.nom_eleve(L.classe_registre(d['config'].get('classe', '')), ek) or ''
            court = (nom[:1] + '. ' + nom.split(' ')[-1]) if nom else ''
            aff = [n for (x, n) in lignes if x == court]
            if os.environ.get('DBG') and not aff: print('   DBG nom', repr(nom), repr(court))
            tot += 1
            if aff and aff[0] == attendu: bons += 1
            else: ecarts.append((did[:20], ek, aff[:1], attendu))
    note('A. Suivi : note affichée = calcul exact, %d fiches sur %d' % (bons, tot), bons == tot and tot > 0, str(ecarts[:4]))
    note('A. réseau : 0 accès au vrai hub, 0 erreur de page', not b.violations and not b.erreurs, str(b.violations[:2] + b.erreurs[:2]))
    b.fermer()
# ---------- B et C. l'écran élève ----------
if os.environ.get('PARTIE', 'AB') in ('B', 'AB'):
    rnd = random.Random(int(os.environ.get('GRAINE', '5'))); n = int(os.environ.get('NB', '8')); DEBUT = int(os.environ.get('DEBUT', '0'))
    cands = []
    for did, D in L.BASE['correction_dictee'].items():
        for ek in (D.get('results') or {}):
            e = L.erreurs(did, ek); k = len([x for x in e if x.get('type') != 'A'])
            cl = L.classe_registre(D['config'].get('classe', ''))
            if 1 <= k <= 9 and cl and L.nom_eleve(cl, ek): cands.append((did, ek))
    rnd.shuffle(cands); nko = 0
    for s in range(DEBUT, DEBUT + n):
        did, ek = cands[s % len(cands)]; errs = L.erreurs(did, ek)
        idx = [i for i, e in enumerate(errs) if e.get('type') != 'A']; N = len(idx)
        plan = {i: rnd.choice([0, 0, 1, 2, 3]) for i in idx}
        ratés = sum(plan.values()); att = fr(exact(N, ratés))
        db = copy.deepcopy(L.BASE); Dd = db['correction_dictee'][did]; Dd['copyPublishedAt'] = Dd.get('copyPublishedAt') or 1790000000000; Dd.setdefault('autocorrection', {}).pop(ek, None)
        b = Banc(F); p = L.ouvrir(b, did, ek, db)
        consigne = p.evaluate("()=>{const x=[...document.querySelectorAll('p')].find(e=>e.textContent.includes('Note de départ'));return x?x.textContent:''}")
        cout = fr(math.floor(5 / N * 100 + 0.5) / 100)
        L.jouer(p, errs, plan); p.wait_for_timeout(700)
        fin = p.evaluate("()=>{const x=[...document.querySelectorAll('div')].find(e=>e.children.length===0&&/^\\d+(,\\d+)?\\/5$/.test(e.textContent.trim()));return x?x.textContent.trim():null}")
        fiche = b.lire(p, 'correction_dictee/%s/autocorrection/%s' % (did, ek)) or {}
        ko = []
        if ('coûte %s pt ; le premier est offert' % cout) not in consigne: ko.append('consigne « %s »' % consigne[-60:])
        if fin != att + '/5': ko.append('page de fin %s ≠ %s/5' % (fin, att))
        if fiche.get('score') != exact(N, ratés): ko.append('enregistrée %s ≠ %s' % (fiche.get('score'), exact(N, ratés)))
        if b.violations or b.erreurs: ko.append('réseau/erreurs')
        nko += bool(ko)
        print('   session %02d %s/%s : N=%d, %d ratés → %s/5%s' % (s + 1, did[:22], ek, N, ratés, att, '' if not ko else '  KO ' + '; '.join(ko)), flush=True)
        b.fermer()
    note('B. Écran élève : consigne, page de fin et note enregistrée, sessions %d à %d' % (DEBUT + 1, DEBUT + n), nko == 0, '%d en échec' % nko)
print('\nBILAN : %s' % ('TOUT PASSE' if all(bilan) else 'ÉCHEC')); sys.exit(0 if all(bilan) else 1)
