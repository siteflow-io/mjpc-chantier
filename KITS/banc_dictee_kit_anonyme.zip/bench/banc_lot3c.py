"""Banc du lot 3c — binômes, moitié réduite et verrouillée, aide entre voisins, par le geste."""
import sys, copy, json, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
now=lambda:int(time.time()*1000)
BASE=L.BASE['correction_dictee'][DGD]; cl=L.classe_registre(BASE['config']['classe'])
# binômes attendus : même règle que l'app (moins d'erreurs avec plus d'erreurs)
res=BASE['results']; ab=BASE.get('absents') or {}
def nerr(k):
    e=res[k].get('errors') or []; e=e if isinstance(e,list) else list(e.values()); x=res[k].get('extras') or []; x=x if isinstance(x,list) else list(x.values())
    return len([y for y in e if y and y.get('type')!='A'])+len(x)
l=sorted([k for k in res if not ab.get(k)],key=lambda k:(nerr(k),k)); BIN={}
i,j=0,len(l)-1
while i<j: BIN[l[i]]=l[j]; BIN[l[j]]=l[i]; i+=1; j-=1
A='bzzinet_azzet'; PA=BIN[A]; nomA=L.nom_eleve(cl,A); nomPA=L.nom_eleve(cl,PA)
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000
D['heure']={'debut':now()-5*60000,'fin':now()+50*60000}; D['binomes']=BIN
for k in (A,PA): D['autocorrection'][k]={'attestation':{'t':1},'sessionDebut':now()-4*60000}
def ident(k,nom,dic=None): return {'identite':{'nom':nom,'cle':k,'classe':cl,'via':'code'},'t':now(),'dictee':dic}
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(700)
p.evaluate("(a)=>{localStorage.setItem('cd_places',JSON.stringify({n:2,t:Date.now()}));localStorage.setItem('cd_moitie_1',JSON.stringify(a))}",ident(A,nomA)); p.reload(); p.wait_for_timeout(2200)
t=p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(x=>x.innerText)")
note('1. à droite, le binôme calculé est déjà affiché : « Ton binôme : %s », code seul'%nomPA,('Ton binôme : '+nomPA) in t[1] and 'tape ton code' in t[1] and 'Nom' not in t[1].split('Ton binôme')[1][:40])
note('2. à gauche, %s lit le nom de son binôme (%s)'%(nomA,nomPA),('Ton binôme : '+nomPA) in t[0],t[0][:120].replace('\n',' | '))
p.evaluate("()=>{const m=document.querySelectorAll('.moitie')[1];[...m.querySelectorAll('button')].find(x=>x.textContent.includes('Pas là ?')).click()}"); p.wait_for_timeout(400)
note('3. « Pas là ? Choisir un autre élève » : le formulaire complet revient','Entre ton code personnel' in p.evaluate("()=>document.querySelectorAll('.moitie')[1].innerText"))
b.fermer()
# 4-7 : Amauri a fini (stylo vert fini depuis 40 s), son binôme corrige encore
errsA=L.erreurs(DGD,A); fin={str(i):True for i,e in enumerate(errsA) if e.get('type')!='A'}; att={str(i):1 for i in fin}
db2=copy.deepcopy(db); F2=db2['correction_dictee'][DGD]['autocorrection']
F2[A].update({'results':fin,'attempts':att,'styloFin':now()-40000,'status':'done'})
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db2); p.wait_for_timeout(700)
p.evaluate("(a)=>{localStorage.setItem('cd_places',JSON.stringify({n:2,t:Date.now()}));localStorage.setItem('cd_moitie_1',JSON.stringify(a[0]));localStorage.setItem('cd_moitie_2',JSON.stringify(a[1]))}",[ident(A,nomA,DGD),ident(PA,nomPA,DGD)]); p.reload(); p.wait_for_timeout(3000)
g=p.evaluate("()=>{const m=[...document.querySelectorAll('.moitie')];return {l:m.map(x=>Math.round(x.getBoundingClientRect().width)),verrou:!!m[0].querySelector('.moitie-verrou'),txt0:m[0].innerText,txt1:m[1].innerText}}")
prA=nomA.split(' ')[-1]; prB=nomPA.split(' ')[-1]
note('4. %s a fini : sa moitié se réduit et se verrouille'%prA,g['verrou'] and g['l'][0]<g['l'][1]*0.6,str(g['l']))
note('5. message de la moitié verrouillée (« quand %s aura fini sa correction… »)'%prB,('quand %s aura fini sa correction'%prB) in g['txt0'])
note('6. chez %s, la phrase pour les deux élèves'%prB,('%s, c’est toi qui tapes et qui réfléchis. %s, explique-lui'%(prB,prA)) in g['txt1'])
bn=b.lire(p,'correction_dictee/%s/binomes'%DGD) or {}
note('7. les deux connectés : leur binôme est rangé au hub',bn.get(A)==PA and bn.get(PA)==A)
# 8. le binôme finit : la moitié se rouvre d'elle-même
errsB=L.erreurs(DGD,PA)
p.evaluate("(a)=>{window.__FAKE_DB_SET__(a[0],a[1])}",['correction_dictee/%s/autocorrection/%s/results'%(DGD,PA),{str(i):True for i,e in enumerate(errsB) if e.get('type')!='A'}]); p.wait_for_timeout(2500)
g=p.evaluate("()=>{const m=[...document.querySelectorAll('.moitie')];return {l:m.map(x=>Math.round(x.getBoundingClientRect().width)),verrou:!!m[0].querySelector('.moitie-verrou')}}")
note('8. %s a fini à son tour : la moitié de %s se rouvre toute seule'%(prB,prA),not g['verrou'] and abs(g['l'][0]-g['l'][1])<20,str(g))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
# 9. les 30 secondes de consultation
db3=copy.deepcopy(db2); db3['correction_dictee'][DGD]['autocorrection'][A]['styloFin']=now()-5000
b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db3); p.wait_for_timeout(700)
p.evaluate("(a)=>{localStorage.setItem('cd_places',JSON.stringify({n:2,t:Date.now()}));localStorage.setItem('cd_moitie_1',JSON.stringify(a[0]));localStorage.setItem('cd_moitie_2',JSON.stringify(a[1]))}",[ident(A,nomA,DGD),ident(PA,nomPA,DGD)]); p.reload(); p.wait_for_timeout(2600)
t0=p.evaluate("()=>document.querySelectorAll('.moitie')[0].innerText"); v=p.evaluate("()=>!!document.querySelectorAll('.moitie')[0].querySelector('.moitie-verrou')")
note('9. juste après le stylo vert : « Tu peux consulter ta copie » avec le compte à rebours, pas encore verrouillée','Tu peux consulter ta copie' in t0 and not v)
b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
