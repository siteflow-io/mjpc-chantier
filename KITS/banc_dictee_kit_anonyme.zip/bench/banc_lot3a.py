"""Banc du lot 3a — l'heure lancée par le professeur, par le geste (le temps qui passe est simulé en déplaçant l'heure de fin)."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; U='dictee_5e_chapitre_utopie-5e_herge'; EK='bzzinet_azzet'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
MIN=60000; now=lambda: int(time.time()*1000)
def txt(p): return p.inner_text('body').replace('\xa0',' ')
# ── professeur
db=copy.deepcopy(L.BASE)
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('grandes')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1200)
bt=p.get_by_role('button',name='▶ Lancer l’autocorrection')
note('1. le suivi propose « ▶ Lancer l’autocorrection », heure de fin préremplie, infobulle',bt.count()==1 and 'Je t’alerte 5 minutes avant' in (bt.get_attribute('title') or ''))
bt.click(); p.wait_for_timeout(700); H=b.lire(p,'correction_dictee/%s/heure'%DGD) or {}
note('2. lancée : l’heure est rangée (début, fin dans ~55 min) et le suivi l’affiche',abs(H.get('fin',0)-H.get('debut',0)-55*MIN)<2*MIN and 'Autocorrection en cours' in txt(p))
p.get_by_role('button',name='+10 min').click(); p.wait_for_timeout(600); H2=b.lire(p,'correction_dictee/%s/heure'%DGD)
note('3. « +10 min » repousse la fin de 10 minutes',abs(H2['fin']-H['fin']-10*MIN)<2000)
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()+4*60000)",'correction_dictee/%s/heure/fin'%DGD); p.wait_for_timeout(700)
note('4. à 4 minutes de la fin : l’alerte du suivi','La séance se termine dans 4 minutes' in txt(p))
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/heure/fin'%DGD); p.wait_for_timeout(700)
t=txt(p); note('5. à l’heure de fin : la fenêtre « Fin de l’heure », où en est la classe',('Fin de l’heure' in t) and ('Où en est la classe' in t) and ('Clôturer ferme les questions' in t))
p.get_by_role('button',name='■ Clôturer l’heure').first.click(); p.wait_for_timeout(700); H3=b.lire(p,'correction_dictee/%s/heure'%DGD)
note('6. « Clôturer » : heure close, le suivi repropose de lancer',H3.get('cloture') is True and 'Dernière heure close à' in txt(p))
note('réseau professeur : 0 accès au vrai hub, 0 erreur',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
# ── élève
def eleve(heure,dict_=DGD,ek=EK,cfg=None):
    dbx=copy.deepcopy(L.BASE); D=dbx['correction_dictee'][dict_]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(ek,None)
    if heure: D['heure']=heure
    if cfg: D['config'].update(cfg)
    bx=Banc(F,900,900); px=L.ouvrir(bx,dict_,ek,dbx); px.wait_for_timeout(900); return bx,px
bx,px=eleve({'debut':now()-50*MIN,'fin':now()+3*MIN-5000})
note('7. élève dans l’heure lancée : l’alerte suit votre heure de fin (« Plus que 3 minutes »)','Plus que 3 minutes.' in txt(px)); bx.fermer()
errs=L.erreurs(DGD,EK)
bx,px=eleve({'debut':now()-40*MIN,'fin':now()+20*MIN,'cloture':True,'clotureA':now()-MIN})
L.jouer(px,errs,{0:2,1:1,2:0,3:0,4:0,5:0}); px.wait_for_timeout(1200); t=txt(px)
note('8. heure clôturée : pas de questions','L’heure est terminée : les questions sont fermées.' in t or 'Plus le temps pour les questions' in t); bx.fermer()
bx,px=eleve({'debut':now()-3*24*60*MIN,'fin':now()-3*24*60*MIN+55*MIN,'cloture':True,'clotureA':now()-3*24*60*MIN+55*MIN})
t=txt(px); note('9. élève hors de l’heure (absent, chez lui) : sa propre session, sans alerte','Tu as 6 erreurs à retrouver' in t and 'Plus que' not in t); bx.fermer()
eu=[k for k in L.BASE['correction_dictee'][U]['results'] if 1<=len([x for x in L.erreurs(U,k) if x.get('type')!='A'])<=4 and L.nom_eleve(L.classe_registre(L.BASE['correction_dictee'][U]['config']['classe']),k)][0]
ee=L.erreurs(U,eu)
bx,px=eleve({'debut':now()-10*MIN,'fin':now()+45*MIN},U,eu,{'exercicesOuverts':True})
L.jouer(px,ee,{i:0 for i,e in enumerate(ee) if e.get('type')!='A'}); px.wait_for_timeout(1000)
dans=px.evaluate("()=>!![...document.querySelectorAll('button')].find(x=>x.textContent.includes('Mes exercices'))"); bx.fermer()
bx,px=eleve(None,U,eu,{'exercicesOuverts':True}); L.jouer(px,ee,{i:0 for i,e in enumerate(ee) if e.get('type')!='A'}); px.wait_for_timeout(1000)
hors=px.evaluate("()=>!![...document.querySelectorAll('button')].find(x=>x.textContent.includes('Mes exercices'))"); bx.fermer()
note('10. bouton d’exercices : absent pendant votre heure, présent hors de l’heure',(not dans) and hors,'dans l’heure %s, hors %s'%(dans,hors))
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
