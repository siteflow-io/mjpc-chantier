"""Méga-fuzzing — sessions au hasard, par le geste, invariants vérifiés dans la fiche et à l'écran.
FAMILLE=F1 (écran seul) | F2 (tablette en deux moitiés) | F3 (votre suivi) ; GRAINE, NB, DEBUT."""
import sys, os, copy, json, math, random, time, unicodedata; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; FAM=os.environ.get('FAMILLE','F1'); G=int(os.environ.get('GRAINE','1')); NB=int(os.environ.get('NB','5')); DEB=int(os.environ.get('DEBUT','0'))
rnd=random.Random(G*1000+DEB); now=lambda:int(time.time()*1000)
BQ=json.load(open('../banque/banque.js')); IDS={q['id'] for t in BQ for q in BQ[t]}; REP={q['id']:q for t in BQ for q in BQ[t]}
def fr(x):
    v=math.floor(x*100+0.5)/100; t=repr(float(v)); t=t[:-2] if t.endswith('.0') else t; return t.replace('.',',')
def dic(o): return o if isinstance(o,dict) else ({str(i):v for i,v in enumerate(o) if v is not None} if isinstance(o,list) else {})
def note_attendue(fiche,errs):
    idx={str(i) for i,e in enumerate(errs) if e.get('type')!='A'}; N=len(idx)
    A=dic(fiche.get('attempts')); R=dic(fiche.get('results')); Q=dic(fiche.get('questions'))
    rates=sum(((A[k] or 0)-(1 if R.get(k) else 0)) for k in A if k in idx)
    c=min(N,max(0,rates-1)); r=min(c,sum(1 for q in Q.values() if isinstance(q,dict) and q.get('ok') is True))
    return 5.0 if N==0 else max(0.0,5*(N-c+r)/N)
def invariants(fiche,errs,fini):
    ko=[]; idx={str(i) for i,e in enumerate(errs) if e.get('type')!='A'}
    for champ in ('attempts','results','history'):
        hors=[k for k in dic(fiche.get(champ)) if k not in idx]
        if hors: ko.append('%s hors des erreurs %s'%(champ,hors[:3]))
    if fini and len([k for k,v in dic(fiche.get('results')).items() if v])!=len(idx): ko.append('trouvées ≠ erreurs')
    Q=dic(fiche.get('questions'))
    for k,q in Q.items():
        if not isinstance(q,dict) or q.get('id') not in IDS: ko.append('question inconnue %s'%q); continue
        if q.get('ok') not in (True,False,'passe',None): ko.append('réponse mal rangée %s'%q)
    sc=fiche.get('score'); att=math.floor(note_attendue(fiche,errs)*100+0.5)/100
    if sc is not None and abs(sc-att)>0.005: ko.append('note enregistrée %s ≠ calcul %s'%(sc,att))
    return ko
DICTS=[d for d in L.BASE['correction_dictee'] if d!='dictee_test_en_attente']
def eleves(did,maxN=10):
    D=L.BASE['correction_dictee'][did]; cl=L.classe_registre(D['config'].get('classe',''))
    return [k for k in (D.get('results') or {}) if L.nom_eleve(cl,k) and 1<=len([e for e in L.erreurs(did,k) if e.get('type')!='A'])<=maxN]
bilan={'sessions':0,'echecs':0,'faute_acceptee':0}; journal=[]
def fin_session(nom,ko,b):
    if b.violations: ko.append('accès au vrai hub %s'%b.violations[:1])
    if b.erreurs: ko.append('erreur de page %s'%b.erreurs[:1])
    bilan['sessions']+=1; bilan['echecs']+=bool(ko)
    print(('KO  ' if ko else 'OK  ')+nom+('  — '+'; '.join(ko)[:300] if ko else ''),flush=True)
def fermer_popup(p):
    p.evaluate("()=>{const o=document.querySelector('.popup-overlay');if(o)o.click()}")
# ────────────── F1 : un élève sur un écran, au hasard ──────────────
def F1(s):
    did=rnd.choice(DICTS); ek=rnd.choice(eleves(did)); errs=L.erreurs(did,ek)
    idx=[i for i,e in enumerate(errs) if e.get('type')!='A']; N=len(idx)
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][did]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000; D.setdefault('autocorrection',{}).pop(ek,None)
    b=Banc(F,900,900); p=L.ouvrir(b,did,ek,db); ko=[]; recharges=0; fautes=0
    ordre=idx[:]; rnd.shuffle(ordre)
    for i in ordre:
        if rnd.random()<0.08:
            p.reload(); p.wait_for_timeout(1500); recharges+=1
        sp=p.query_selector('span.word-btn[data-err="%d"]'%i)
        if not sp: ko.append('mot %d introuvable'%i); break
        sp.click(); p.wait_for_timeout(150)
        for _ in range(rnd.choice([0,0,0,1,1,2,3])):
            f=errs[i].get('fautif')
            essai=f if (f and rnd.random()<0.5) else ''.join(rnd.choice('abcdefghéèàç') for _ in range(rnd.randint(2,8)))
            p.fill('input[placeholder="Tape le mot correct…"]',essai); p.get_by_role('button',name='✓').click(); p.wait_for_timeout(950)
            if p.query_selector('span.word-btn[data-err="%d"]'%i) is None:
                fautes+=1; break
            if not p.query_selector('.popup-overlay input'): p.query_selector('span.word-btn[data-err="%d"]'%i).click(); p.wait_for_timeout(120)
        if p.query_selector('span.word-btn[data-err="%d"]'%i) is None: continue
        if not p.query_selector('.popup-overlay input'): p.query_selector('span.word-btn[data-err="%d"]'%i).click(); p.wait_for_timeout(120)
        p.fill('input[placeholder="Tape le mot correct…"]',errs[i]['word']); p.get_by_role('button',name='✓').click(); p.wait_for_timeout(1400)
    p.wait_for_timeout(900)
    p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/autocorrection/%s/styloFin'%(did,ek)); p.wait_for_timeout(1300)
    nq=0
    for _ in range(12):
        bt=p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Répondre à une question'));if(b){b.click();return true}return false}")
        if not bt: break
        p.wait_for_timeout(400); fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(did,ek)) or {}
        Q=dic(fic.get('questions')); ouverte=[q for q in Q.values() if isinstance(q,dict) and q.get('ok') is None]
        if not ouverte: ko.append('question ouverte absente'); break
        q=REP[ouverte[-1]['id']]; geste=rnd.choice(['juste','faux','passer'])
        if geste=='passer':
            p.get_by_role('button',name='Passer (la question est perdue)').click(); p.wait_for_timeout(200); p.get_by_role('button',name='Oui, je passe').click()
        else:
            txt=q['choix'][0] if geste=='juste' else q['choix'][1]
            p.evaluate("(t)=>[...document.querySelectorAll('.popup-overlay button')].find(x=>x.textContent===t).click()",txt); p.wait_for_timeout(300)
            p.get_by_role('button',name='Continuer').click()
        p.wait_for_timeout(500); nq+=1
    fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(did,ek)) or {}
    ko+=invariants(fic,errs,True)
    aff=p.evaluate("()=>{const x=[...document.querySelectorAll('div')].find(e=>e.children.length===0&&/^\\d+(,\\d+)?\\/5$/.test(e.textContent.trim()));return x?x.textContent.trim():null}")
    att=fr(note_attendue(fic,errs))+'/5'
    if aff!=att: ko.append('note affichée %s ≠ %s'%(aff,att))
    if not fic.get('sessionDebut'): ko.append('pas de début de session')
    bilan['faute_acceptee']+=fautes
    fin_session('F1 %02d %s/%s N=%d, %d rechargement(s), %d question(s), note %s%s'%(s+1,did[:18],ek,N,recharges,nq,att,(', sa faute acceptée %d fois'%fautes) if fautes else ''),ko,b); b.fermer()
# ────────────── F2 : deux élèves sur une tablette, gestes mêlés ──────────────
def F2(s):
    did=rnd.choice([d for d in DICTS if len(eleves(d,8))>=2]); a,c=rnd.sample(eleves(did,8),2)
    D0=L.BASE['correction_dictee'][did]; cl=L.classe_registre(D0['config'].get('classe',''))
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][did]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000
    for k in (a,c): D.setdefault('autocorrection',{})[k]={'attestation':{'t':1}}
    b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(700)
    ide=lambda k:{'identite':{'nom':L.nom_eleve(cl,k),'cle':k,'classe':cl,'via':'code'},'t':now(),'dictee':did}
    p.evaluate("(x)=>{localStorage.setItem('cd_places',JSON.stringify({n:2,t:Date.now()}));localStorage.setItem('cd_moitie_1',JSON.stringify(x[0]));localStorage.setItem('cd_moitie_2',JSON.stringify(x[1]))}",[ide(a),ide(c)]); p.reload(); p.wait_for_timeout(2600)
    ko=[]; E={0:L.erreurs(did,a),1:L.erreurs(did,c)}; cles={0:a,1:c}; gestes=0; rech=0
    def taper(m,txt):
        for ch in txt:
            lab='espace' if ch==' ' else ('’' if ch=="'" else ch.lower())   # l'app ne distingue pas majuscules et minuscules
            ok=p.evaluate("(x)=>{const mm=document.querySelectorAll('.moitie')[x[0]];const bs=[...mm.querySelectorAll('button')];let b=bs.find(y=>y.textContent===x[1]);if(!b&&x[1]!==x[1].toLowerCase()){const s=bs.find(y=>y.textContent==='⇧');if(s){s.click();b=[...mm.querySelectorAll('button')].find(y=>y.textContent===x[1])||[...mm.querySelectorAll('button')].find(y=>y.textContent===x[1].toLowerCase())}}if(!b)return false;b.click();return true}",[m,lab])
            if not ok: return False
        return True
    for g in range(rnd.randint(10,22)):
        m=rnd.choice([0,1]); restants=p.evaluate("(m)=>[...document.querySelectorAll('.moitie')[m].querySelectorAll('span.word-btn[data-err]')].map(x=>+x.dataset.err)",m)
        if not restants: continue
        i=rnd.choice(restants); p.evaluate("(x)=>document.querySelectorAll('.moitie')[x[0]].querySelector('span.word-btn[data-err=\"'+x[1]+'\"]').click()",[m,i]); p.wait_for_timeout(250)
        act=rnd.random(); mot=E[m][i]['word']
        if act<0.15:
            taper(m,mot[:max(1,len(mot)//2)]); p.reload(); p.wait_for_timeout(2600); rech+=1
            v=p.evaluate("(m)=>{const x=document.querySelectorAll('.moitie')[m].querySelector('.saisie-moitie');return x?x.textContent:null}",m)
            if v!=mot[:max(1,len(mot)//2)]: ko.append('lettres perdues au rechargement (%s)'%v)
            p.evaluate("(m)=>{const b=[...document.querySelectorAll('.moitie')[m].querySelectorAll('button')].find(x=>x.textContent==='✕');b&&b.click()}",m)
        elif act<0.25:
            p.evaluate("(m)=>{const b=[...document.querySelectorAll('.moitie')[m].querySelectorAll('button')].find(x=>x.textContent==='✕');b&&b.click()}",m)
        else:
            faux=act<0.45
            if not taper(m,('zq'+mot[::-1])[:6] if faux else mot):
                etat=p.evaluate("(m)=>{const mm=document.querySelectorAll('.moitie')[m];return {feuille:!!mm.querySelector('.saisie-moitie'),verrou:!!mm.querySelector('.moitie-verrou'),touches:[...mm.querySelectorAll('button')].slice(0,6).map(b=>b.textContent)}}",m)
                ko.append('caractère impossible à taper dans « %s » %s'%(mot,etat)); continue
            p.evaluate("(m)=>[...document.querySelectorAll('.moitie')[m].querySelectorAll('button')].find(x=>x.textContent==='✓ Valider').click()",m); p.wait_for_timeout(1500)
            if faux: p.evaluate("(m)=>{const b=[...document.querySelectorAll('.moitie')[m].querySelectorAll('button')].find(x=>x.textContent==='✕');b&&b.click()}",m)
        gestes+=1
    p.wait_for_timeout(900)
    for m in (0,1):
        fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(did,cles[m])) or {}
        ko+=['moitié %d : %s'%(m+1,x) for x in invariants(fic,E[m],False)]
    autres=[l['path'] for l in b.log(p) if '/autocorrection/' in l['path'] and not any(('/autocorrection/'+k) in l['path'] for k in (a,c))]
    if autres: ko.append('écriture dans la fiche d’un autre élève %s'%autres[:2])
    fin_session('F2 %02d %s : %s + %s, %d gestes, %d rechargement(s)'%(s+1,did[:18],a,c,gestes,rech),ko,b); b.fermer()
# ────────────── F3 : votre suivi, gestes au hasard ──────────────
def F3(s):
    did=rnd.choice(DICTS); D0=L.BASE['correction_dictee'][did]; titre=D0['config'].get('title',''); classe=D0['config'].get('classe','')
    db=copy.deepcopy(L.BASE); b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
    p.evaluate('''(a)=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes(a[0])&&x.textContent.includes(a[1])&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}''',[titre,classe]); p.wait_for_timeout(1300)
    p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1400)
    ko=[]; faits=[]
    for g in range(rnd.randint(6,12)):
        a=rnd.choice(['lancer','plus10','finir','cloturer','oeil','ramasser','ligne'])
        clic=lambda t: p.evaluate("(t)=>{const b=[...document.querySelectorAll('button')].filter(x=>x.textContent===t);if(!b.length)return false;b[b.length-1].click();return true}",t)
        if a=='lancer': clic('▶ Lancer l’autocorrection')
        elif a=='plus10': clic('+10 min')
        elif a=='finir': p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/heure/fin'%did)
        elif a=='cloturer': clic('■ Clôturer l’heure')
        elif a=='oeil':
            p.evaluate("()=>{const b=[...document.querySelectorAll('button')].filter(x=>x.textContent==='👁');if(b.length)b[Math.floor(Math.random()*b.length)].click()}")
            p.wait_for_timeout(300); clic('✕ Fermer')
        elif a=='ramasser': p.evaluate("()=>{const x=document.querySelector('.etape-clignote');x&&x.click()}")
        elif a=='ligne':
            p.evaluate("()=>{const r=[...document.querySelectorAll('tbody tr')];if(r.length){const x=r[Math.floor(Math.random()*r.length)];x.click();setTimeout(()=>x.click(),200)}}"); p.wait_for_timeout(450)
        faits.append(a); p.wait_for_timeout(350)
        if not p.evaluate("()=>!!document.querySelector('tbody tr')"): ko.append('le tableau a disparu après %s'%a); break
    fin_session('F3 %02d %s : %s'%(s+1,did[:18],' '.join(faits)),ko,b); b.fermer()

# ────────────── F5 : deux élèves sur une tablette, avec leurs VRAIES fiches (finies ou non l'an dernier) ──────────────
def F5(s):
    did=rnd.choice([d for d in DICTS if len(eleves(d,40))>=2]); a,c=rnd.sample(eleves(did,40),2)
    D0=L.BASE['correction_dictee'][did]; cl=L.classe_registre(D0['config'].get('classe',''))
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][did]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000
    D['heure']={'debut':now()-5*60000,'fin':now()+45*60000}
    b=Banc(F,1280,800); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(700)
    ide=lambda k:{'identite':{'nom':L.nom_eleve(cl,k),'cle':k,'classe':cl,'via':'code'},'t':now(),'dictee':did}
    p.evaluate("(x)=>{localStorage.setItem('cd_places',JSON.stringify({n:2,t:Date.now()}));localStorage.setItem('cd_moitie_1',JSON.stringify(x[0]));localStorage.setItem('cd_moitie_2',JSON.stringify(x[1]))}",[ide(a),ide(c)]); p.reload(); p.wait_for_timeout(3000)
    for m in (0,1):
        if p.evaluate("(m)=>document.querySelectorAll('.moitie')[m].innerText.includes('J’ai lu et compris')",m):
            p.evaluate("(m)=>{const mm=document.querySelectorAll('.moitie')[m];[...mm.querySelectorAll('label')].find(l=>l.textContent.includes('J’ai lu et compris')).click()}",m); p.wait_for_timeout(150)
            p.evaluate("(m)=>{const mm=document.querySelectorAll('.moitie')[m];[...mm.querySelectorAll('button')].find(b=>b.textContent.includes('Commencer mon autocorrection')).click()}",m); p.wait_for_timeout(900)
    ko=[]; E={0:L.erreurs(did,a),1:L.erreurs(did,c)}; cles={0:a,1:c}
    def etat():
        return p.evaluate("()=>[...document.querySelectorAll('.moitie')].map(m=>({verrou:!!m.querySelector('.moitie-verrou'),corrige:m.innerText.includes('Note de départ'),fin:m.innerText.includes('Autocorrection de la dictée')||m.innerText.includes('Bravo pour tout')}))")
    def controle_verrou(quand):
        e=etat()
        for m in (0,1):
            o=1-m; fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(did,cles[m])) or {}; sf=fic.get('styloFin') or 0
            attendu=e[m]['fin'] and not (sf>0 and now()<sf+30000) and e[o]['corrige'] and not e[o]['verrou']
            if e[m]['verrou']!=attendu and not (e[m]['verrou'] and e[o]['corrige']): ko.append('%s : moitié %d verrou=%s, attendu %s'%(quand,m+1,e[m]['verrou'],attendu))
    controle_verrou('au départ')
    for g in range(rnd.randint(6,14)):
        m=rnd.choice([0,1]); restants=p.evaluate("(m)=>[...document.querySelectorAll('.moitie')[m].querySelectorAll('span.word-btn[data-err]')].map(x=>+x.dataset.err)",m)
        if not restants or p.evaluate("(m)=>!!document.querySelectorAll('.moitie')[m].querySelector('.moitie-verrou')",m): continue
        i=rnd.choice(restants); p.evaluate("(x)=>document.querySelectorAll('.moitie')[x[0]].querySelector('span.word-btn[data-err=\"'+x[1]+'\"]').click()",[m,i]); p.wait_for_timeout(250)
        mot=E[m][i]['word']
        for ch in mot:
            lab='espace' if ch==' ' else ('’' if ch=="'" else ch.lower())
            p.evaluate("(x)=>{const mm=document.querySelectorAll('.moitie')[x[0]];const b=[...mm.querySelectorAll('button')].find(y=>y.textContent===x[1]);b&&b.click()}",[m,lab])
        p.evaluate("(m)=>{const b=[...document.querySelectorAll('.moitie')[m].querySelectorAll('button')].find(x=>x.textContent==='✓ Valider');b&&b.click()}",m); p.wait_for_timeout(1500)
    p.wait_for_timeout(1500); controle_verrou('à la fin')
    for m in (0,1):
        fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(did,cles[m])) or {}
        ko+=['moitié %d : %s'%(m+1,x) for x in invariants(fic,E[m],False) if 'note enregistrée' not in x]
    autres=[l['path'] for l in b.log(p) if '/autocorrection/' in l['path'] and not any(('/autocorrection/'+k) in l['path'] for k in (a,c))]
    if autres: ko.append('écriture dans la fiche d’un autre élève %s'%autres[:2])
    fin_session('F5 %02d %s : %s + %s (fiches réelles)'%(s+1,did[:18],a,c),ko,b); b.fermer()
for s in range(DEB,DEB+NB):
    try: {'F1':F1,'F2':F2,'F3':F3,'F5':F5}[FAM](s)
    except Exception as e:
        try:
            import banc as _b
            for x in list(getattr(_b,'OUVERTS',[])): x.fermer()
        except Exception: pass
        bilan['sessions']+=1; bilan['echecs']+=1; print('KO  %s %02d exception : %s'%(FAM,s+1,str(e).split('\n')[0][:200]),flush=True)
print('BILAN %s graine %d : %d sessions, %d en échec, faute de l’élève acceptée comme juste : %d fois'%(FAM,G,bilan['sessions'],bilan['echecs'],bilan['faute_acceptee']))
