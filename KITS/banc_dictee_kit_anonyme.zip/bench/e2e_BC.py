"""De bout en bout, parties B et C — rendre les copies, lire chaque copie des familles, puis connexion des élèves
avec de vrais codes chiffrés (même calcul que le site) et autocorrection complète. Suite de la partie A (même hub)."""
import sys, copy, json, random, math, os, time, re; sys.argv=['x','a','b']; sys.path.insert(0,'.')
os.environ['BANC_SECURISE']='1'
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; BAREME=os.environ.get('BAREME','brevet'); rnd=random.Random(5)
S=json.load(open('/tmp/e2e_%s.json'%BAREME)); db=S['db']; did=S['did']; att=S['attendu']
bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
fr=lambda x: (str(round(x,2)).rstrip('0').rstrip('.') if '.' in str(round(x,2)) else str(round(x,2))).replace('.',',')
TITRE=db['correction_dictee'][did]['config']['title']
# B. rendre les copies, puis lire chaque copie des familles
b=Banc(F,1400,900); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(1000); dlg=[]; p.on('dialog',lambda d: dlg.append(d.message))
p.evaluate("(t)=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes(t)&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}",TITRE); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='📄 Copies').first.click(); p.wait_for_timeout(1200)
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Rendre les copies'));b.click()}"); p.wait_for_timeout(1200)
pub=b.lire(p,'correction_dictee/%s/copyPublishedAt'%did)
note('4. « Rendre les copies » : copies rendues, sans alerte (le seul sans copie est absent)',bool(pub) and not any('pas de copie corrigée' in m for m in dlg),str(dlg[:1])[:150])
ko=[]
R=b.lire(p,'correction_dictee/%s/results'%did)
for k,(nom,errs,extras) in att.items():
    court=nom.split(' ')[0][:1]+'. '+nom.split(' ')[-1]
    p.get_by_text(court).first.click(); p.wait_for_timeout(1800)
    html=' '.join(f.content() for f in p.frames if f!=p.main_frame)
    r=R[k]; n_att=len([e for e in (r.get('errors') or []) if e])
    brut=re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',html))
    if not re.search(r'Note : ?%s ?/ ?10'%re.escape(fr(r['note'])),brut): ko.append('%s : note %s absente (%s)'%(nom,fr(r['note']),(re.search(r'Note :.{0,20}',brut) or [''])[0]))
    m=re.search(r'Détail des erreurs \((\d+)\)',html)
    if not m or int(m.group(1))!=n_att+len([x for x in (r.get('extras') or []) if x]) and int(m.group(1))!=n_att: ko.append('%s : détail des erreurs %s (copie : %d)'%(nom,m.group(1) if m else '—',n_att))
    if 'À recopier sur la copie' not in html: ko.append('%s : pas de phrase à recopier'%nom)
    if 'class="num-trou"' in html: ko.append('%s : copie passée en trous'%nom)
note('5. copie des familles de chaque élève : sa note, le détail de ses erreurs, la phrase à recopier, jamais en trous',not ko,'; '.join(ko)[:400])
db=b.lire(p,''); b.fermer()
# C. codes chiffrés comme sur le site, puis connexion et autocorrection de deux élèves
b=Banc(F,800,900); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(1200)
cles=list(att.keys())[:2]; codes={}
for i,k in enumerate(cles):
    nom=att[k][0]; code=str(4100+i*7); codes[k]=code
    ent=p.evaluate("async(a)=>{const sel='a1b2c3d4e5f6'+a[1];const e=await mjpcEmpreinte(a[0],sel);return {sel:sel,empreinte:e}}",[code,str(i)])
    p.evaluate("(a)=>window.__FAKE_DB_SET__('codes/'+a[0],{name:a[1],classe:'3E IMPORT TEST',createdAt:Date.now(),chiffre:'v1.test',sel:a[2].sel,empreinte:a[2].empreinte})",[k,nom,ent])
db=b.lire(p,''); b.fermer()
for k in cles:
    nom=att[k][0]; parts=nom.split(' '); prenom=parts[-1]; nomf=' '.join(parts[:-1])
    b=Banc(F,800,900); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(1200)
    p.fill('input[placeholder="1234"]','0000'); p.fill('input[placeholder="DUPONT"]',nomf); p.fill('input[placeholder="Marie"]',prenom); p.get_by_role('button',name='Entrer').click(); p.wait_for_timeout(1800)
    faux='Mes dictées' not in p.inner_text('body')
    p.fill('input[placeholder="1234"]',codes[k]); p.get_by_role('button',name='Entrer').click(); p.wait_for_timeout(2200)
    t=p.inner_text('body')
    note('6. %s : mauvais code refusé, bon code accepté, sa dictée listée'%nom,faux and 'Mes dictées' in t and TITRE in t,t[:120].replace('\n',' | '))
    p.evaluate("(t)=>{const c=[...document.querySelectorAll('div')].filter(x=>x.textContent.includes(t)&&x.textContent.includes('Ouvrir')&&x.children.length<8);const e=c[c.length-1];const b=[...e.querySelectorAll('button,span,div')].find(x=>x.textContent.trim().startsWith('Ouvrir'));(b||e).click()}",TITRE); p.wait_for_timeout(1500)
    if 'J’ai lu et compris' in p.inner_text('body'):
        p.get_by_text('J’ai lu et compris').click(); p.get_by_role('button',name='Commencer mon autocorrection').click(); p.wait_for_timeout(900)
    errs=[e for e in (db['correction_dictee'][did]['results'][k].get('errors') or []) if e]
    ordre=[i for i,e in enumerate(errs) if e.get('type')!='A']; rates=0
    for i in ordre:
        sp=p.query_selector('span.word-btn[data-err="%d"]'%i)
        if not sp: continue
        sp.click(); p.wait_for_timeout(200)
        if rnd.random()<0.4:
            p.fill('input[placeholder="Tape le mot correct…"]','zzz'); p.get_by_role('button',name='✓').click(); p.wait_for_timeout(950); rates+=1
            if not p.query_selector('.popup-overlay input'): p.query_selector('span.word-btn[data-err="%d"]'%i).click(); p.wait_for_timeout(150)
        p.fill('input[placeholder="Tape le mot correct…"]',errs[i]['word']); p.get_by_role('button',name='✓').click(); p.wait_for_timeout(1400)
    p.wait_for_timeout(900)
    p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/autocorrection/%s/styloFin'%(did,k)); p.wait_for_timeout(1300)
    fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(did,k)) or {}
    N=len(ordre); c=max(0,rates-1); attendue=5.0 if N==0 else max(0,5*(N-c)/N)
    t=p.inner_text('body').replace('\xa0',' ')
    note('7. %s : autocorrection finie (%d erreurs, %d ratés) : note %s/5 affichée et enregistrée'%(nom,N,rates,fr(attendue)),(fr(attendue)+'/5') in t and abs((fic.get('score') or 0)-attendue)<0.006 and 'À recopier chez toi' in t)
    note('   réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
