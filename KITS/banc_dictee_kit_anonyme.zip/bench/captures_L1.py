import sys, copy; sys.path.insert(0,'.')
sys.argv=['x','../livre.html','../work/correction_dictee.html']
import banc_L1 as L
from banc import Banc
DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'
plan={0:1,1:0,2:1,3:0,4:0,5:0}
for nom,f in (('avant','../livre.html'),('apres','../work/correction_dictee.html')):
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop('bzzinet_azzet',None)
    b=Banc(f); errs=L.erreurs(DGD,'bzzinet_azzet'); p=L.ouvrir(b,DGD,'bzzinet_azzet',db)
    p.screenshot(path='cap/L1_%s_1_debut.png'%nom)
    L.jouer(p,errs,plan); p.wait_for_timeout(800)
    p.screenshot(path='cap/L1_%s_2_fin.png'%nom)
    b.fermer()
print('ok')
