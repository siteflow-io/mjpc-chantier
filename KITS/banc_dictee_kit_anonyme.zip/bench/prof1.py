import sys; sys.path.insert(0,'.')
from banc import Banc
f=sys.argv[1]; tag=sys.argv[2]
b=Banc(f,1536,864)
p=b.ouvrir('?mode=prof'); p.wait_for_timeout(1200)
p.get_by_role('button',name='✏️').first.click(); p.wait_for_timeout(900)
p.screenshot(path='cap/%s_A_edition.png'%tag)
print('EDITION:',p.inner_text('body')[:500].replace('\n',' | '))
p.goto('about:blank')
p=b.ouvrir('?mode=prof'); p.wait_for_timeout(1200)
p.get_by_text('Ouvrir →').first.click(); p.wait_for_timeout(1500)
print('ONGLETS',[x.inner_text()[:25] for x in p.query_selector_all('button')][:25])
