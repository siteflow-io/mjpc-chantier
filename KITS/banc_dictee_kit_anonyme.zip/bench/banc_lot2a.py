"""Banc du lot 2a — regagner des points, par le geste."""
import sys, copy, json, math; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; U='dictee_5e_chapitre_utopie-5e_herge'; EK='bzzinet_azzet'
B=json.load(open('../banque/banque.js')); PAR={q['id']:q for t in B for q in B[t]}
bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
def fr(x):
    v=math.floor(x*100+0.5)/100; t=repr(float(v)); t=t[:-2] if t.endswith('.0') else t; return t.replace('.',',')
errs=L.erreurs(DGD,EK); N=len([e for e in errs if e.get('type')!='A'])
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None)
# « déjà répondu » : une trace dans l'autre dictée du même élève, pour toutes les questions
db['correction_dictee'][U].setdefault('autocorrection',{}).setdefault(EK,{})['questions']={str(i):{'id':qid,'ok':True,'t':1791849600000} for i,qid in enumerate(PAR)}
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,db)
enc=p.evaluate("()=>{const c=[...document.querySelectorAll('.card')].find(x=>x.textContent.startsWith('Regagner des points'));return c?c.textContent:''}")
note('1. pendant la correction : encart présent, sans ratés « rien perdu »','Tu n’as rien perdu' in enc,enc[:90])
L.jouer(p,errs,{0:2,1:1,2:0,3:0,4:0,5:0}); p.wait_for_timeout(900)   # 3 ratés → 2 comptés → 2 questions
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/autocorrection/%s/styloFin'%(DGD,EK)); p.wait_for_timeout(1200)   # les 2 minutes de stylo vert sont passées
enc=p.evaluate("()=>{const c=[...document.querySelectorAll('.card')].find(x=>x.textContent.startsWith('Regagner des points'));return c?c.textContent:''}")
note('2. page de fin : 2 questions, 0,83 pt chacune, 1,67 point perdu','2 questions · 0,83 pt chacune' in enc and '1,67 point' in enc,enc[:120])
def ouvrir():
    p.evaluate("()=>[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Répondre à une question')).click()"); p.wait_for_timeout(500)
    return p.evaluate("()=>{const o=document.querySelector('.popup-overlay');return o?o.innerText:''}").replace('\xa0',' ')
t=ouvrir(); q0=b.lire(p,'correction_dictee/%s/autocorrection/%s/questions/0'%(DGD,EK)) or {}
qb=PAR.get(q0.get('id'),{})
note('3. la question s’ouvre : type, « Question 1 sur 2 », mot corrigé, phrase, 3 propositions, « Passer »',
     'Question 1 sur 2' in t and 'Même type d’erreur que « %s »'%errs[0]['word'] in t and qb.get('q','??') in t and all(c in t for c in qb.get('choix',['??'])) and 'Passer (la question est perdue)' in t, 'question %s (%s)'%(q0.get('id'),q0.get('notion')))
note('4. « tu as déjà répondu… lors de la dictée du … » (trace de l’autre dictée)','Tu as déjà répondu à cette question lors de la dictée du' in t and 'tu avais juste' in t, t[:300].replace(chr(10),' | '))
bonne=qb['choix'][0]
p.evaluate("(t)=>[...document.querySelectorAll('.popup-overlay button')].find(x=>x.textContent===t).click()",bonne); p.wait_for_timeout(500)
t=p.evaluate("()=>document.querySelector('.popup-overlay').innerText").replace('\xa0',' ')
note('5. bonne réponse : « tu regagnes 0,83 point » et la règle','tu regagnes 0,83 point' in t and qb['regle'] in t)
p.get_by_role('button',name='Continuer').click(); p.wait_for_timeout(500)
attendu=fr(5*(N-2+1)/N)
fin=p.evaluate("()=>{const x=[...document.querySelectorAll('div')].find(e=>e.children.length===0&&/^\\d+(,\\d+)?\\/5$/.test(e.textContent.trim()));return x?x.textContent.trim():null}")
note('6. la note remonte au prix d’un raté : %s/5 attendu'%attendu, fin==attendu+'/5','affiché %s'%fin)
t=ouvrir(); q1=b.lire(p,'correction_dictee/%s/autocorrection/%s/questions/1'%(DGD,EK)) or {}; qb1=PAR[q1['id']]
note('7. deuxième question différente de la première',q1['id']!=q0['id'],'%s puis %s'%(q0['id'],q1['id']))
p.evaluate("(t)=>[...document.querySelectorAll('.popup-overlay button')].find(x=>x.textContent===t).click()",qb1['choix'][1]); p.wait_for_timeout(500)
t=p.evaluate("()=>document.querySelector('.popup-overlay').innerText").replace('\xa0',' ')
note('8. mauvaise réponse : rien de perdu, bonne réponse et règle montrées','Ce n’est pas la bonne réponse' in t and qb1['choix'][0] in t and qb1['regle'] in t)
p.get_by_role('button',name='Continuer').click(); p.wait_for_timeout(500)
fin2=p.evaluate("()=>{const x=[...document.querySelectorAll('div')].find(e=>e.children.length===0&&/^\\d+(,\\d+)?\\/5$/.test(e.textContent.trim()));return x?x.textContent.trim():null}")
enc=p.evaluate("()=>{const c=[...document.querySelectorAll('.card')].find(x=>x.textContent.startsWith('Regagner des points'));return c?c.textContent:''}")
note('9. note inchangée après la mauvaise réponse, plus de question','%s'%fin2==attendu+'/5' and 'Tu as utilisé toutes tes questions' in enc,'%s | %s'%(fin2,enc[-45:]))
fiche=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(DGD,EK))
note('10. fiche : note enregistrée %s, deux traces (id, notion, erreur, réponse)'%fiche.get('score'),fiche.get('score')==math.floor(5*(N-1)/N*100+0.5)/100 and all(k in (fiche['questions'][0] if isinstance(fiche['questions'],list) else fiche['questions']['0']) for k in ('id','notion','err','ok','t')))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150])
b.fermer()
# « Passer » : un élève à une seule question
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None)
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,db); L.jouer(p,errs,{0:2,1:0,2:0,3:0,4:0,5:0}); p.wait_for_timeout(900)
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/autocorrection/%s/styloFin'%(DGD,EK)); p.wait_for_timeout(1200)
t=ouvrir(); p.get_by_role('button',name='Passer (la question est perdue)').click(); p.wait_for_timeout(300)
t=p.evaluate("()=>document.querySelector('.popup-overlay').innerText").replace('\xa0',' ')
note('11. « Passer » : conséquence annoncée avant de confirmer','tu perds cette question et les 0,83 point' in t and 'Il te restera 0 question' in t and 'Ta note ne baisse pas' in t)
p.get_by_role('button',name='Oui, je passe').click(); p.wait_for_timeout(500)
q=b.lire(p,'correction_dictee/%s/autocorrection/%s/questions/0'%(DGD,EK)) or {}
note('12. question passée rangée « passe », note inchangée',q.get('ok')=='passe' and b.lire(p,'correction_dictee/%s/autocorrection/%s/score'%(DGD,EK))==math.floor(5*(N-1)/N*100+0.5)/100)
b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
