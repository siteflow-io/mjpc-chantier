"""Banc du complément du lot 2 — phrase à recopier, dictée autocorrigée rouvrable, copie des familles."""
import sys, copy; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; EK='bzzinet_azzet'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
ATT='Pour cette dictée, j’ai fait 6 erreurs, surtout de grammaire, et pour la prochaine, je devrai remplacer par « mordre » ou « mordu » pour choisir entre -er et -é.'
errs=L.erreurs(DGD,EK)
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None)
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,db); L.jouer(p,errs,{i:0 for i,e in enumerate(errs) if e.get('type')!='A'}); p.wait_for_timeout(900)
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, 0)",'correction_dictee/%s/autocorrection/%s/styloFin'%(DGD,EK)); p.wait_for_timeout(600)
t=p.inner_text('body').replace('\xa0',' ')
note('1. page de fin : bloc à recopier et la phrase attendue','À recopier chez toi, sur ta copie :' in t and ATT in t)
note('2. page de fin : « Tu as lu et compris les consignes le … », sans mot technique','Tu as lu et compris les consignes le' in t and 'ttestation' not in t)
p.get_by_role('button',name='📄 Ma dictée autocorrigée').click(); p.wait_for_timeout(1500)
src=p.evaluate("()=>{const f=document.querySelector('iframe');return f?(f.srcdoc||''):''}"); corps=p.inner_text('body')
print('   diag3 :', 'Ta dictée corrigée' in corps, ATT in src, 'a lu et compris' in src, len(src))
note('3. le bouton ouvre « Ta dictée corrigée », avec la phrase et la ligne des consignes','Ta dictée corrigée' in corps and ATT in src and 'Amauri a lu et compris les consignes de l’autocorrection le' in src)
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
# 4. copie des familles côté professeur : la phrase y figure
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('grandes')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='📄 Copies').first.click(); p.wait_for_timeout(1200)
p.get_by_text('B. Azzet').first.click(); p.wait_for_timeout(1800)
ct=' '.join(f.content() for f in p.frames if f!=p.main_frame)
print('   diag4 : longueur', len(ct), 'recopier' in ct)
note('4. copie des familles : bloc « À recopier sur la copie » avec la même phrase','À recopier sur la copie' in ct and ATT in ct); b.fermer()
# 5. dictée sans aucune erreur
db2=copy.deepcopy(db); R=db2['correction_dictee'][DGD]['results'][EK]; R['errors']=[]; R['extras']=[]; R['note']=10
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,db2); p.wait_for_timeout(1200); t=p.inner_text('body').replace('\xa0',' ')
note('5. sans aucune erreur : la phrase validée','Pour cette dictée, je n’ai fait aucune erreur, et pour la prochaine, je devrai relire avec le même soin.' in t); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
