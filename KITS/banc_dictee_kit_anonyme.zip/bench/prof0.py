import sys; sys.path.insert(0,'.')
from banc import Banc
b=Banc('../work/correction_dictee.html',1536,864)
p=b.ouvrir('?mode=prof'); p.wait_for_timeout(1500)
print(p.inner_text('body')[:700]); print('BOUTONS',[x.inner_text()[:30] for x in p.query_selector_all('button')][:30])
p.screenshot(path='cap/p0.png')
print(b.erreurs, b.violations)
