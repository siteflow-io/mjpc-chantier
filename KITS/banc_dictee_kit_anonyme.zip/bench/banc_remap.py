import sys, copy, json; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
U='dictee_5e_chapitre_utopie-5e_herge'; EK='azzubor_mzzam'
b=Banc('../work/correction_dictee.html',1536,864); p=b.ouvrir('?mode=prof'); p.wait_for_timeout(1000)
p.get_by_text('Ouvrir →').first.click(); p.wait_for_timeout(1400)
avant=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(U,EK)); ts0=b.lire(p,'correction_dictee/%s/results/%s/timestamp'%(U,EK))
N=len([x for x in L.erreurs(U,EK) if x.get('type')!='A'])
print('avant : total',avant.get('total'),'trouvées',avant.get('solved'),'| erreurs de la copie actuelle (hors A)',N,'| mots gardés',len(avant.get('errorRefs') or []))
p.get_by_role('button',name='Correction').first.click(); p.wait_for_timeout(1200)
ok=p.evaluate('''()=>{const x=[...document.querySelectorAll('button,div,span')].filter(e=>e.children.length<3&&/AZZUBOR|A\\. Maïwen|Maïwen/.test(e.textContent)&&e.textContent.length<40);if(!x.length)return 'introuvable';x[0].click();return x[0].tagName+':'+x[0].textContent.trim()}''')
print('clic élève :',ok); p.wait_for_timeout(1200)
bt=[x.inner_text()[:60] for x in p.query_selector_all('button') if 'Enregistrer' in x.inner_text()]
print('boutons Enregistrer :',bt[:3])
p.evaluate("()=>{window.confirm=()=>false;const x=[...document.querySelectorAll('button')].find(b=>b.textContent.trim().startsWith('Enregistrer ('));if(x)x.click()}"); p.wait_for_timeout(1500)
apres=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(U,EK)); ts1=b.lire(p,'correction_dictee/%s/results/%s/timestamp'%(U,EK)); print('copie réenregistrée :',ts0!=ts1); log=[l['path'] for l in b.log(p)]; print('écritures :',[x for x in log if 'antonini' in x][:8])
print('après : total',apres.get('total'),'trouvées',apres.get('solved'),'note',apres.get('score'),'| erreurs de la copie actuelle',N)
print('réseau',b.violations[:1],'erreurs',b.erreurs[:1]); b.fermer()
