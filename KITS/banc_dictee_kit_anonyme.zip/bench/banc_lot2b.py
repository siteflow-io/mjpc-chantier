"""Banc du lot 2b — l'heure, le stylo vert, l'estimation, les alertes (le temps écoulé est simulé par la date de début de session)."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; EK='bzzinet_azzet'
errs=L.erreurs(DGD,EK); bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
def base(fiche=None):
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None)
    if fiche is not None: D['autocorrection'][EK]=fiche
    return db
def txt(p): return p.inner_text('body').replace('\xa0',' ')
MIN=60000
# S1 : parcours normal
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,base()); p.wait_for_timeout(800)
sd=b.lire(p,'correction_dictee/%s/autocorrection/%s/sessionDebut'%(DGD,EK))
note('1. la session commence à la première ouverture',isinstance(sd,(int,float)) and abs(sd/1000-time.time())<60)
note('2. message du début : « Tu as 6 erreurs à retrouver, environ 4 minutes : tu es capable de garder tous tes points. »','Tu as 6 erreurs à retrouver, environ 4 minutes : tu es capable de garder tous tes points.' in txt(p))
L.jouer(p,errs,{0:1,1:1,2:0}); p.wait_for_timeout(500)
t=txt(p); note('3. dès la 3e erreur, l’estimation verte','À ton rythme, il te restera environ' in t and 'pour tes questions' in t)
L.jouer(p,errs,{3:0,4:0,5:0},deja=(0,1,2)); p.wait_for_timeout(900)
t=p.evaluate("()=>{const o=[...document.querySelectorAll('.popup-overlay')].pop();return o?o.innerText:''}").replace('\xa0',' ')
note('4. fin de correction : stylo vert, 2 minutes, ses corrections','Tu as 2 minutes pour écrire ta correction en vert' in t and any(('1:5%d'%k in t) for k in range(10)) or '2:00' in t and 'voulaient échanger' in t, t[:160].replace('\n',' | '))
enc=p.evaluate("()=>{const c=[...document.querySelectorAll('.card')].find(x=>x.textContent.startsWith('Regagner des points'));return c?c.textContent:''}")
note('5. pendant le stylo vert, les questions restent fermées','Se débloque après ta correction et ton stylo vert' in enc and not p.evaluate("()=>!![...document.querySelectorAll('button')].find(x=>x.textContent.includes('Répondre à une question'))"))
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/autocorrection/%s/styloFin'%(DGD,EK)); p.wait_for_timeout(1500)
note('6. après les 2 minutes : le bouton s’ouvre',p.evaluate("()=>!![...document.querySelectorAll('button')].find(x=>x.textContent.includes('Répondre à une question'))") and not p.query_selector('.popup-overlay'))
note('réseau S1 : 0 accès au vrai hub, 0 erreur',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
# S2 : trop lent → message rouge et astuces tirées de ses erreurs
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,base({'sessionDebut':int(time.time()*1000)-45*MIN})); p.wait_for_timeout(600)
L.jouer(p,errs,{0:1,1:0,2:0}); p.wait_for_timeout(500); t=txt(p)
note('7. trop lent : le message rouge validé','À ce rythme, tu finiras ta correction après la fin de l’heure et tu ne pourras pas regagner de points.' in t)
note('8. astuces tirées de ses erreurs trouvées','Sur ta dictée, tu as buté sur « échanger »' in t,str([l for l in t.split(chr(10)) if 'buté' in l][:3]))
b.fermer()
# S3 : alertes 5 puis 3 minutes
for dm,attendu,nom in ((51,'Plus que 5 minutes.','9. à 4 minutes de la fin : alerte orange'),(53,'Plus que 3 minutes.','10. à 2 minutes de la fin : alerte rouge')):
    b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,base({'sessionDebut':int(time.time()*1000)-dm*MIN})); p.wait_for_timeout(800)
    note(nom,attendu in txt(p)); b.fermer()
# S4 : moins de 4 minutes à la fin de la correction → pas de stylo imposé, pas de questions
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,base({'sessionDebut':int(time.time()*1000)-52*MIN})); p.wait_for_timeout(600)
L.jouer(p,errs,{0:2,1:1,2:0,3:0,4:0,5:0}); p.wait_for_timeout(1200); t=txt(p)
note('11. moins de 4 minutes : « Plus le temps pour les questions… », pas de stylo vert','Plus le temps pour les questions : corrige ta copie au stylo vert, puis rends-la.' in t and 'Tu as 2 minutes pour écrire' not in t)
b.fermer()
# S5 : heure finie
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,base({'sessionDebut':int(time.time()*1000)-60*MIN})); p.wait_for_timeout(600)
L.jouer(p,errs,{0:2,1:1,2:0,3:0,4:0,5:0}); p.wait_for_timeout(1200); t=txt(p)
note('12. heure passée : questions fermées, correction possible jusqu’au bout','L’heure est terminée : les questions sont fermées.' in t or 'Plus le temps pour les questions' in t, 'correction terminée' if 'Bravo' in t else '')
b.fermer()
# S6 : ancienne autocorrection terminée, sans session → pas de session créée, questions fermées
fic=copy.deepcopy(L.BASE['correction_dictee'][DGD]['autocorrection'].get('bonnin_louann') or {})
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000
b=Banc(F,900,900); p=L.ouvrir(b,DGD,'bonnin_louann',db); p.wait_for_timeout(1200)
sd=b.lire(p,'correction_dictee/%s/autocorrection/bonnin_louann/sessionDebut'%DGD); t=txt(p)
note('13. autocorrection déjà terminée rouverte : aucune session créée, pas de questions',sd is None and 'Répondre à une question' not in t,'sessionDebut=%s'%sd)
b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
