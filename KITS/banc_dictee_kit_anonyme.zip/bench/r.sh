#!/bin/sh
# r.sh <étiquette> <délai> <commande…> : lance un banc et n'en garde que le verdict
et=$1; d=$2; shift 2
timeout $d "$@" > /tmp/r_$et.txt 2>&1
python3 -c "
t=open('/tmp/r_$et.txt','rb').read().decode('utf-8','replace');L=[l for l in t.splitlines() if l.startswith(('KO','BILAN','OK  A. Suivi','OK  B.','OK  légende','nouveau'))]
print('$et :',' | '.join(x[:150] for x in L) or 'AUCUNE SORTIE — '+t[-200:].replace(chr(10),' '))"
