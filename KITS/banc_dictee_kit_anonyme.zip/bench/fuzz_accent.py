"""Contrôle ciblé : l'élève retape exactement sa propre faute d'accent — l'app la prend-elle pour juste ?"""
import sys, copy, json, unicodedata; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
def norm(s): return ''.join(c for c in unicodedata.normalize('NFD',s) if unicodedata.category(c)!='Mn').lower().replace('\u2019',"'")
cas=[]
for did,D in L.BASE['correction_dictee'].items():
    cl=L.classe_registre((D.get('config') or {}).get('classe',''))
    for ek in (D.get('results') or {}):
        if not (cl and L.nom_eleve(cl,ek)): continue
        for i,e in enumerate(L.erreurs(did,ek)):
            f=e.get('fautif')
            if e.get('type')!='A' and f and f!=e['word'] and norm(f)==norm(e['word']): cas.append((did,ek,i,f,e['word']))
print('cas à essayer :',len(cas))
acc=0; essais=0
for did,ek,i,f,w in cas[:8]:
    db=copy.deepcopy(L.BASE); Dd=db['correction_dictee'][did]; Dd['copyPublishedAt']=Dd.get('copyPublishedAt') or 1790000000000; Dd.setdefault('autocorrection',{}).pop(ek,None)
    b=Banc('../work/correction_dictee.html',900,900); p=L.ouvrir(b,did,ek,db)
    sp=p.query_selector('span.word-btn[data-err="%d"]'%i)
    if not sp: b.fermer(); continue
    sp.click(); p.wait_for_timeout(150); p.fill('input[placeholder="Tape le mot correct…"]',f); p.get_by_role('button',name='✓').click(); p.wait_for_timeout(1500)
    trouve=p.query_selector('span.word-btn[data-err="%d"]'%i) is None; essais+=1; acc+=trouve
    print('   %s : attendu « %s », l’élève retape sa faute « %s » → %s'%(ek,w,f,'ACCEPTÉE comme juste' if trouve else 'refusée')); b.fermer()
print('BILAN : sa propre faute acceptée %d fois sur %d essais'%(acc,essais))
