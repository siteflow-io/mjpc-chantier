"""Banc du lot 1c, seconde partie — par le geste."""
import sys, copy; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; U='dictee_5e_chapitre_utopie-5e_herge'; B='dictee_brevet_blanc_4e-4e_banksy'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
# 1. panneau d'édition : la ligne, son état, l'enregistrement
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof'); p.wait_for_timeout(1000)
p.get_by_role('button',name='✏️').first.click(); p.wait_for_timeout(900)
ligne=p.evaluate("()=>{const l=[...document.querySelectorAll('label')].find(x=>x.textContent.includes('Exercices ouverts'));return l?{t:l.parentElement.textContent,c:l.querySelector('input').checked,w:l.querySelector('input').getBoundingClientRect().width,tip:l.parentElement.title}:null}")
note('1a. ligne « Exercices » présente, décochée par défaut, avec le contenu de la dictée',bool(ligne) and not ligne['c'] and '7 exercices de classe, 31 élèves' in ligne['t'],str(ligne and ligne['t']))
note('1b. infobulle écrite pour vous',bool(ligne) and 'Décocher cache tout' in ligne['tip'])
note('1c. case à cocher à sa taille (pas étirée)',bool(ligne) and ligne['w']<30,'largeur %s px'%(ligne and round(ligne['w'])))
p.evaluate("()=>[...document.querySelectorAll('label')].find(x=>x.textContent.includes('Exercices ouverts')).querySelector('input').click()"); p.wait_for_timeout(200)
p.get_by_role('button',name='Enregistrer').first.click(); p.wait_for_timeout(600)
note('1d. « Enregistrer » range la case dans la dictée',b.lire(p,'correction_dictee/%s/config/exercicesOuverts'%U) is True)
larg=p.evaluate("()=>[...document.querySelectorAll('input[type=checkbox]')].map(i=>Math.round(i.getBoundingClientRect().width)).filter(w=>w>0)")
note('1e. toutes les cases à cocher visibles à leur taille',all(w<30 for w in larg),'largeurs %s'%sorted(set(larg)))
b.fermer()
# 2. fin d'autocorrection : le bouton suit la case et l'existence d'exercices
def fin(did,ek,ouverts):
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][did]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000; D['autocorrection'].pop(ek,None)
    if ouverts: D['config']['exercicesOuverts']=True
    errs=L.erreurs(did,ek); bb=Banc(F); pp=L.ouvrir(bb,did,ek,db); L.jouer(pp,errs,{i:0 for i,x in enumerate(errs) if x.get('type')!='A'}); pp.wait_for_timeout(800)
    r=pp.evaluate("()=>!![...document.querySelectorAll('button')].find(x=>x.textContent.includes('Mes exercices'))"); bb.fermer(); return r
eu=[(ek) for ek in L.BASE['correction_dictee'][U]['results'] if 1<=len([x for x in L.erreurs(U,ek) if x.get('type')!='A'])<=5 and L.nom_eleve(L.classe_registre(L.BASE['correction_dictee'][U]['config']['classe']),ek)][0]
eb=[(ek) for ek in L.BASE['correction_dictee'][B]['results'] if 1<=len([x for x in L.erreurs(B,ek) if x.get('type')!='A'])<=5 and L.nom_eleve(L.classe_registre(L.BASE['correction_dictee'][B]['config']['classe']),ek)][0]
r1=fin(U,eu,False); r2=fin(U,eu,True); r3=fin(B,eb,True)
note('2. bouton « Mes exercices » en fin d’autocorrection : case décochée → %s, cochée → %s, cochée sans exercices → %s'%(r1,r2,r3),(not r1) and r2 and (not r3))
# 3. la porte des exercices, par l'ancien lien
for ouv in (False,True):
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000
    if ouv: D['config']['exercicesOuverts']=True
    cl=L.classe_registre(D['config']['classe']); nom=L.nom_eleve(cl,eu)
    bb=Banc(F); pp=bb.ouvrir('?mode=eleve&dicteeId=%s&eleveKey=%s&screen=exercices'%(U,eu),db=db,session={'display':nom,'classe':cl}); pp.wait_for_timeout(1800)
    t=pp.inner_text('body'); bb.fermer()
    fermee='ne sont pas ouverts' in t
    note('3%s. lien des exercices, case %s → %s'%('ab'[ouv],'cochée' if ouv else 'décochée','porte fermée' if fermee else 'exercices ouverts'),fermee!=ouv)
# 4. Réglages : la case par défaut a disparu ; Copies : le rappel
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof'); p.wait_for_timeout(1000); p.get_by_text('Ouvrir →').first.click(); p.wait_for_timeout(1400)
p.get_by_role('button',name='Réglages').first.click(); p.wait_for_timeout(900)
note('4a. Réglages : plus de case « Ajouter le lien vers les exercices »','Ajouter le lien vers les exercices' not in p.inner_text('body'))
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='📄 Copies').first.click(); p.wait_for_timeout(1200)
t=p.inner_text('body'); note('4b. Copies : le rappel « se règle avec ✏️ sur la dictée » remplace la case','se règle avec ✏️ sur la dictée' in t and 'Inclus dans la copie' not in t)
b.fermer()
# 5. fenêtre de saisie : un clic dans la marge la ferme
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(eu,None)
b=Banc(F,1366,900); p=L.ouvrir(b,U,eu,db); p.wait_for_timeout(600)
p.query_selector_all('span.word-btn[style*="cursor: pointer"]')[0].click(); p.wait_for_timeout(300)
ouverte=bool(p.query_selector('.popup-overlay input')); p.mouse.click(20,700); p.wait_for_timeout(300)
note('5. un clic dans la marge ferme la fenêtre de saisie',ouverte and not p.query_selector('.popup-overlay input'))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:120]); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
