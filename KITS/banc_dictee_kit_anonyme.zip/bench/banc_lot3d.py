"""Banc du lot 3d (1/2) — votre suivi par étapes, copie ramassée, binômes groupés, par le geste."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
now=lambda:int(time.time()*1000); M=60000
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000
cl=L.classe_registre(D['config']['classe'])
ks=[k for k in D['results'] if L.nom_eleve(cl,k) and 2<=len([e for e in L.erreurs(DGD,k) if e.get('type')!='A'])<=6][:7]
A,B,C,Dd,E,Fk,G=ks
def fiche(k,fini,**x):
    e=L.erreurs(DGD,k); idx=[str(i) for i,y in enumerate(e) if y.get('type')!='A']
    f={'attestation':{'t':1},'sessionDebut':now()-10*M,'attempts':{i:1 for i in idx},'results':{i:True for i in (idx if fini else idx[:1])},'status':'done' if fini else 'active','lastSeen':now()}
    f.update(x); return f
D['heure']={'debut':now()-12*M,'fin':now()+40*M}
AC=D['autocorrection']={}
AC[A]=fiche(A,False)
AC[B]=fiche(B,True,styloFin=now()+90000)
AC[C]=fiche(C,True,styloFin=now()-5000)
AC[Dd]=fiche(Dd,True,styloFin=now()-60000,copieRamassee=1)
AC[E]=fiche(E,False)
AC[Fk]=fiche(Fk,True,styloFin=now()-60000,copieRamassee=1); eF=[str(i) for i,y in enumerate(L.erreurs(DGD,Fk)) if y.get('type')!='A']; AC[Fk]['attempts'][eF[0]]=4
AC[G]=fiche(G,False,sessionDebut=now()-2*24*60*M)
D['binomes']={Dd:E,E:Dd}
nom=lambda k: L.nom_eleve(cl,k); court=lambda k: nom(k)[:1]+'. '+nom(k).split(' ')[-1]
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('grandes')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1500)
def etape(k):
    return p.evaluate("(n)=>{const t=[...document.querySelectorAll('table')].find(x=>x.textContent.includes('Note corr.'));const hs=[...t.querySelectorAll('th')].map(h=>h.textContent.trim());const j=hs.indexOf('Élève'),s=hs.indexOf('Statut');const r=[...t.querySelectorAll('tbody tr')].find(r=>r.children[j].textContent.trim()===n);return r?r.children[s].textContent.trim():null}",court(k))
e={k:etape(k) for k in ks}
note('1. en train de corriger : « Corrige 1/… »',(e[A] or '').startswith('Corrige 1/'),e[A])
note('2. pendant le stylo vert : « Stylo vert 1:… »',(e[B] or '').startswith('Stylo vert 1:'),e[B])
note('3. après le stylo vert : « A fini, doit rendre sa copie », qui clignote',e[C]=='A fini, doit rendre sa copie' and p.evaluate("()=>!!document.querySelector('.etape-clignote')"),e[C])
note('4. copie ramassée, binôme qui corrige encore : « Tuteur de %s »'%nom(E).split(' ')[-1],e[Dd]=='Tuteur de '+nom(E).split(' ')[-1],e[Dd])
note('5. copie ramassée, questions à faire : « Questions 0/… »',(e[Fk] or '').startswith('Questions 0/'),e[Fk])
note('6. heure passée sans avoir fini : « Pas fini, à terminer »',e[G]=='Pas fini, à terminer',e[G])
p.evaluate("()=>document.querySelector('.etape-clignote').click()"); p.wait_for_timeout(700)
cr=b.lire(p,'correction_dictee/%s/autocorrection/%s/copieRamassee'%(DGD,C)); e2=etape(C)
note('7. un tap : la copie est notée ramassée, la ligne ne clignote plus',bool(cr) and e2!='A fini, doit rendre sa copie',str(e2))
ordre=p.evaluate("()=>{const t=[...document.querySelectorAll('table')].find(x=>x.textContent.includes('Note corr.'));const hs=[...t.querySelectorAll('th')].map(h=>h.textContent.trim());const j=hs.indexOf('Élève');return [...t.querySelectorAll('tbody tr')].map(r=>r.children[j].textContent.trim())}")
i1,i2=ordre.index(court(Dd)),ordre.index(court(E))
note('8. les deux élèves d’un binôme sont côte à côte',abs(i1-i2)==1,'%d et %d'%(i1,i2))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
b=Banc(F,800,900); p=b.ouvrir('?mode=eleve',db=db); p.wait_for_timeout(900)
note('9. connexion : plus de mention de MJPC pour l’élève','MJPC' not in p.inner_text('body') and 'Si tu as oublié ton code, viens me le demander.' in p.inner_text('body')); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
