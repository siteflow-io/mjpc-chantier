import sys,copy,json; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; EK='bzzinet_azzet'
db=copy.deepcopy(L.BASE); f=db['correction_dictee'][DGD]['autocorrection'][EK]
# une fiche réelle, à laquelle on ajoute une question réussie : la note du suivi doit monter d'un cran
N=len([e for e in L.erreurs(DGD,EK) if e.get('type')!='A'])
b=Banc('../work/correction_dictee.html',1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
def note_suivi():
    p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('grandes')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
    p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1200)
    return p.evaluate('''()=>{const t=[...document.querySelectorAll('table')].find(x=>x.textContent.includes('Note corr.'));const hs=[...t.querySelectorAll('th')].map(h=>h.textContent.trim());const i=hs.indexOf('Note corr.'),j=hs.indexOf('Élève');const r=[...t.querySelectorAll('tbody tr')].find(r=>r.children[j].textContent.trim()==='B. Azzet');return r?r.children[i].textContent.trim():null}''')
avant=note_suivi()
print('fiche réelle : ratés', f.get('attempts'), '| note suivi', avant)
b.fermer()
f['attempts']={'0':3,'1':2}; f['results']={'0':True,'1':True}; f['questions']={'0':{'id':'G1','ok':True,'t':1},'1':{'id':'G2','ok':False,'t':2}}
b=Banc('../work/correction_dictee.html',1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
apres=note_suivi(); import math
att=math.floor(5*(N-2+1)/N*100+0.5)/100
print('3 ratés (2 comptés), 1 question réussie sur 2 → attendu', str(att).replace('.',','),'| suivi', apres, 'OK' if apres==str(att).replace('.',',')+'/5' else 'KO'); b.fermer()
