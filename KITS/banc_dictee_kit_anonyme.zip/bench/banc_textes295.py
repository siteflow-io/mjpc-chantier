"""Point 295 — 5/5 « parfaite » et 4,5 à 4,99 « presque », titre et phrase accordés, par le geste (page de fin)."""
import sys, copy, time; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; bilan=[]; now=lambda:int(time.time()*1000)
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
def fin(did,ek,rate_premier=0,note_dictee=None):
    e=L.erreurs(did,ek); idx=[str(i) for i,x in enumerate(e) if x.get('type')!='A']
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][did]; D['copyPublishedAt']=D.get('copyPublishedAt') or 1790000000000
    f={'attestation':{'t':now()-600000},'sessionDebut':now()-20*60000,'attempts':{i:1 for i in idx},'results':{i:True for i in idx},'status':'done','styloFin':now()-60000}
    f['attempts'][idx[0]]=1+rate_premier; D['autocorrection'][ek]=f
    if note_dictee is not None: D['results'][ek]['note']=note_dictee
    b=Banc(F,900,900); p=L.ouvrir(b,did,ek,db); p.wait_for_timeout(1300); t=p.inner_text('body').replace('\xa0',' ')
    ko=b.violations+b.erreurs; b.fermer(); return t,ko
U='dictee_5e_chapitre_utopie-5e_herge'; B3='dictee_brevet_blanc_3e-3e_charles_de_gaulle'
t,ko=fin(U,'bzzetor_czzix',rate_premier=1)
note('1. Candice 5/5, dictée 14,5/20 : « Autocorrection parfaite » et « sans faille »','Autocorrection parfaite, Candice.' in t and 'presque parfaite' not in t and 'Bonne dictée, et une autocorrection sans faille.' in t and not ko)
t,ko=fin(U,'pzzilil_czzal',rate_premier=2)
note('2. Clémence 4,55/5, dictée 11,5/20 : « presque parfaite » et « presque sans faute »','4,55/5' in t and 'Autocorrection presque parfaite, Clemence.' in t and 'Bonne dictée, et une autocorrection presque sans faute.' in t and not ko)
t,ko=fin(U,'pzzilil_czzal',rate_premier=2,note_dictee=16)
note('3. la même à 16/20 : « Très bonne dictée et autocorrection presque parfaite. Encore un peu d’attention… »','Très bonne dictée et autocorrection presque parfaite. Encore un peu d’attention et ce sera parfait.' in t and not ko)
t,ko=fin(B3,'bzzovil_czzek',rate_premier=0)
note('4. Céleste 5/5, dictée 0,5/10 : « tu as retrouvé toutes tes erreurs » (sans « presque »)','Autocorrection parfaite, Céleste.' in t and 'Mais tu as retrouvé toutes tes erreurs toi-même' in t and not ko)
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
