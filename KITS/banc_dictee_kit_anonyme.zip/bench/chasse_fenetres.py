"""Chasse F6 — fenêtres combinées, dans tous les ordres (votre suivi), et une question ouverte au moment de la clôture (élève)."""
import sys, copy, time, random, json; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; U='dictee_5e_chapitre_utopie-5e_herge'; now=lambda:int(time.time()*1000); rnd=random.Random(61); ko_tot=0
for s in range(3):
    db=copy.deepcopy(L.BASE); D=db['correction_dictee'][U]; D['heure']={'debut':now()-50*60000,'fin':now()+20*60000}
    D['binomes']={'bzzetor_czzix':'czzilin_lzzal','czzilin_lzzal':'bzzetor_czzix'}
    b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
    p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('utopie')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1300)
    p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1300)
    clic=lambda t: p.evaluate("(t)=>{const b=[...document.querySelectorAll('button')].filter(x=>x.textContent.trim()===t);if(!b.length)return false;b[b.length-1].click();return true}",t)
    ko=[]; faits=[]
    for g in range(16):
        a=rnd.choice(['vue','fermer','oeil','fermer_oeil','finir','plus_tard','plus10','cloturer','lancer'])
        if a=='vue': p.evaluate("()=>{const r=[...document.querySelectorAll('tbody tr')].filter(x=>x.textContent.includes('Terminé')||x.textContent.includes('Corrige'));if(r.length)r[Math.floor(Math.random()*r.length)].click()}")
        elif a=='fermer': clic('✕ Fermer') or clic('Fermer')
        elif a=='oeil': p.evaluate("()=>{const b=[...document.querySelectorAll('button')].filter(x=>x.textContent==='👁');if(b.length)b[Math.floor(Math.random()*b.length)].click()}")
        elif a=='fermer_oeil': clic('✕ Fermer')
        elif a=='finir': p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/heure/fin'%U)
        elif a=='plus_tard': clic('Plus tard')
        elif a=='plus10': clic('+10 min')
        elif a=='cloturer': clic('■ Clôturer l’heure')
        elif a=='lancer': clic('▶ Lancer l’autocorrection')
        p.wait_for_timeout(450); faits.append(a)
        e=p.evaluate("""()=>{const t=document.body.innerText;const vue=[...document.querySelectorAll('div')].some(d=>d.style&&d.style.position==='fixed'&&d.style.zIndex==='300');const direct=t.includes('En direct —');
          const modales=[...document.querySelectorAll('.popup-overlay')].filter(o=>o.innerText.includes('Où en est la classe'));
          return {vue:vue,direct:direct,modales:modales.length,boutons:modales.length?['+10 min','■ Clôturer l’heure','Plus tard'].every(x=>[...modales[0].querySelectorAll('button')].some(b=>b.textContent.trim()===x)):true}}""")
        if (e['vue'] or e['direct']) and e['modales']: ko.append('après %s : la fenêtre de fin d’heure recouvre une vue ouverte'%a)
        if e['modales']>1: ko.append('après %s : %d fenêtres de fin d’heure'%(a,e['modales']))
        if not e['boutons']: ko.append('après %s : un bouton manque dans la fenêtre'%a)
    if b.erreurs or b.violations: ko.append(str((b.erreurs+b.violations)[:1]))
    ko_tot+=bool(ko); print(('KO  ' if ko else 'OK  ')+'F6 %02d suivi : %s'%(s+1,' '.join(faits))+('  — '+'; '.join(sorted(set(ko)))[:300] if ko else ''),flush=True); b.fermer()
# élève : une question ouverte au moment où vous clôturez l'heure
DGD='dictee_preparee_5e_grandes_decouvertes-5e_herge'; EK='bzzinet_azzet'; errs=L.erreurs(DGD,EK)
db=copy.deepcopy(L.BASE); D=db['correction_dictee'][DGD]; D['copyPublishedAt']=1790000000000; D['autocorrection'].pop(EK,None); D['heure']={'debut':now()-10*60000,'fin':now()+40*60000}
b=Banc(F,900,900); p=L.ouvrir(b,DGD,EK,db); L.jouer(p,errs,{0:2,1:1,2:0,3:0,4:0,5:0}); p.wait_for_timeout(900)
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, Date.now()-1000)",'correction_dictee/%s/autocorrection/%s/styloFin'%(DGD,EK)); p.wait_for_timeout(1200)
p.evaluate("()=>[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Répondre à une question')).click()"); p.wait_for_timeout(600)
fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(DGD,EK)); Q=fic.get('questions'); Q=Q if isinstance(Q,dict) else {str(i):v for i,v in enumerate(Q) if v}
BQ=json.load(open('../banque/banque.js')); REP={x['id']:x for t_ in BQ for x in BQ[t_]}; qid=list(Q.values())[-1]['id']
p.evaluate("(c)=>window.__FAKE_DB_SET__(c, {debut:Date.now()-50*60000,fin:Date.now()+20*60000,cloture:true,clotureA:Date.now()})",'correction_dictee/%s/heure'%DGD); p.wait_for_timeout(800)
visible=bool(p.query_selector('.popup-overlay'));msg='L’heure est terminée : cette question n’est plus comptée.' in p.inner_text('body')
if visible:
    p.evaluate("(t)=>{const b=[...document.querySelectorAll('.popup-overlay button')].find(x=>x.textContent===t);b&&b.click()}",REP[qid]['choix'][0]); p.wait_for_timeout(500)
fic=b.lire(p,'correction_dictee/%s/autocorrection/%s'%(DGD,EK)); Q=fic.get('questions'); Q=Q if isinstance(Q,dict) else {str(i):v for i,v in enumerate(Q) if v}
ok_apres=[v for v in Q.values() if v.get('ok') is True]
print('ÉLÈVE : question ouverte au moment de la clôture → message « plus comptée » : %s ; réponse juste comptée après la clôture : %s'%(msg,bool(ok_apres)))
b.fermer(); print('BILAN F6 : %d sessions de suivi en échec'%ko_tot)
