"""Gardes du 29/09 — corbeille avant tout effacement de copie, restauration, alerte à « Rendre les copies » — par le geste."""
import sys, copy, json; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; D3='dictee_brevet_blanc_3e-3e_charles_de_gaulle'; bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
db=copy.deepcopy(L.BASE); ORIG=copy.deepcopy(db['correction_dictee'][D3]['results']['czzoros_pzzet']); ORIGAC=copy.deepcopy(db['correction_dictee'][D3]['autocorrection'].get('czzoros_pzzet'))
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900)
dialogues=[]
def surDialogue(d):
    dialogues.append(d.message)
    try: d.accept() if not d.message.startswith('⚠') or ACCEPTER[0] else d.dismiss()
    except Exception: pass
ACCEPTER=[False]; p.on('dialog',surDialogue)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('brevet blanc 3E')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1400)
def ouvrir_eleve(nom):
    p.evaluate("(n)=>{const x=[...document.querySelectorAll('*')].filter(e=>e.children.length===0&&e.textContent.trim()===n);(x[0].closest('button,[role=button],div[style*=cursor]')||x[0]).click()}",nom); p.wait_for_timeout(900)
ouvrir_eleve('C. Pzzet')
p.evaluate("()=>[...document.querySelectorAll('button')].find(x=>x.textContent==='↻'&&(x.title||'').startsWith('Réinitialiser')).click()"); p.wait_for_timeout(1500)
cb=b.lire(p,'corbeille') or {}
arch=[(j,k,v) for j,vv in cb.items() if isinstance(vv,dict) for k,v in vv.items() if k.startswith('effacement-copie_') and k.endswith('_czzoros_pzzet')]
res=b.lire(p,'correction_dictee/%s/results/czzoros_pzzet'%D3)
note('1. ↻ Réinitialiser : la copie part d’abord dans la corbeille MJPC, puis elle est effacée',len(arch)==1 and arch[0][2]['data']['results']==ORIG and arch[0][2]['_meta']['geste']=='reinitialiser' and res is None,'corbeille/%s/%s'%(arch[0][0],arch[0][1]) if arch else 'aucune archive')
note('   son autocorrection est archivée avec elle',bool(arch) and arch[0][2]['data'].get('autocorrection')==ORIGAC)
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent==='←');b&&b.click()}"); p.wait_for_timeout(700)
ouvrir_eleve('C. Pzzet'); t=p.inner_text('body')
note('2. en rouvrant l’élève : « Une copie de CZZOROS Pzzet a été effacée le … (Réinitialiser, note 7,5/10) »','Une copie de CZZOROS Pzzet a été effacée le' in t and '(Réinitialiser, note 7,5/10)' in t)
p.get_by_role('button',name='↺ La restaurer').click(); p.wait_for_timeout(1300)
res=b.lire(p,'correction_dictee/%s/results/czzoros_pzzet'%D3); ac=b.lire(p,'correction_dictee/%s/autocorrection/czzoros_pzzet'%D3)
note('3. « ↺ La restaurer » : la copie et son autocorrection reviennent à l’identique',res==ORIG and ac==ORIGAC and 'La restaurer' not in p.inner_text('body'))
# 4. transfert vers Line : archive, puis restauration de la copie de départ
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent==='←');b&&b.click()}"); p.wait_for_timeout(700)
ORIG2=copy.deepcopy(db['correction_dictee'][D3]['results']['czzinov_azzub'])
ouvrir_eleve('C. Azzub')
p.get_by_title('Transférer cette correction vers un autre élève').click(); p.wait_for_timeout(500)
p.fill('input[placeholder="Initiales (ex: DA pour Durand Alice)…"]','CL'); p.wait_for_timeout(500)
p.evaluate("()=>{const r=[...document.querySelectorAll('div')].filter(d=>d.textContent.includes('CZZALUR Lzzub')&&d.querySelector('button'));const c=r[r.length-1];[...c.querySelectorAll('button')].find(b=>b.textContent.includes('Transférer')).click()}"); p.wait_for_timeout(1500)
cb=b.lire(p,'corbeille') or {}; arch=[(j,k,v) for j,vv in cb.items() if isinstance(vv,dict) for k,v in vv.items() if k.startswith('effacement-copie_') and k.endswith('_czzinov_azzub')]
line=b.lire(p,'correction_dictee/%s/results/czzalur_lzzub'%D3); chan=b.lire(p,'correction_dictee/%s/results/czzinov_azzub'%D3)
note('4. 🔀 Transférer d’Aymeric vers Line : la copie d’Aymeric est archivée avant de partir',len(arch)==1 and arch[0][2]['_meta']['geste']=='transferer' and chan is None and line is not None and line.get('note')==ORIG2.get('note'))
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
# 5. « Rendre les copies » : l'alerte pour Line
db=copy.deepcopy(L.BASE)
b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(900); dialogues=[]; ACCEPTER=[False]; p.on('dialog',surDialogue)
p.evaluate('''()=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes('brevet blanc 3E')&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}'''); p.wait_for_timeout(1400)
p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='📄 Copies').first.click(); p.wait_for_timeout(1200)
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Rendre les copies')||x.textContent.includes('Rendre à nouveau'));b.click()}"); p.wait_for_timeout(900)
pub=b.lire(p,'correction_dictee/%s/copyPublishedAt'%D3)
note('6. « Rendre les copies » : l’alerte « 1 élève présent n’a pas de copie corrigée : CZZALUR Lzzub » s’affiche avant ; « Rendre quand même » rend les copies',any('1 élève présent n’a pas de copie corrigée : CZZALUR Lzzub' in m for m in dialogues) and pub is not None)
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150]); b.fermer()
print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
