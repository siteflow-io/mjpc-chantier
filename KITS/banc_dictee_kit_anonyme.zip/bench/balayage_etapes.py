"""Balayage : l'étape affichée pour CHAQUE élève des 5 dictées réelles (données de l'an dernier), comparée à la règle."""
import sys, copy; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; ko=[]; vus=0
def dic(o): return o if isinstance(o,dict) else ({str(i):v for i,v in enumerate(o) if v is not None} if isinstance(o,list) else {})
for did,D0 in L.BASE['correction_dictee'].items():
    if did=='dictee_test_en_attente': continue
    cfg=D0['config']; b=Banc(F,1536,864); p=b.ouvrir('?mode=prof',db=copy.deepcopy(L.BASE)); p.wait_for_timeout(900)
    p.evaluate('''(a)=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes(a[0])&&x.textContent.includes(a[1])&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}''',[cfg.get('title',''),cfg.get('classe','')]); p.wait_for_timeout(1300)
    p.get_by_role('button',name='Données').first.click(); p.wait_for_timeout(400); p.get_by_role('button',name='Suivi 🟢').first.click(); p.wait_for_timeout(1400)
    lignes=p.evaluate("()=>{const t=[...document.querySelectorAll('table')].find(x=>x.textContent.includes('Note corr.'));const hs=[...t.querySelectorAll('th')].map(h=>h.textContent.trim());const j=hs.indexOf('Élève'),s=hs.indexOf('Statut');return [...t.querySelectorAll('tbody tr')].map(r=>[r.children[j].textContent.trim(),r.children[s].textContent.trim()])}")
    cl=L.classe_registre(cfg.get('classe','')); AC=D0.get('autocorrection') or {}
    for ek,f in AC.items():
        nom=L.nom_eleve(cl,ek)
        if not nom: continue
        court=nom[:1]+'. '+nom.split(' ')[-1]; lab=[x[1] for x in lignes if x[0]==court]
        if not lab: continue
        errs=L.erreurs(did,ek); idx={str(i) for i,e in enumerate(errs) if e.get('type')!='A'}
        fini=len([k for k,v in dic(f.get('results')).items() if v and k in idx])>=len(idx) and len(idx)>0
        att='Terminé' if fini else 'Corrige'
        vus+=1
        if not lab[0].startswith(att): ko.append('%s/%s : « %s » (attendu %s…)'%(did[:14],ek,lab[0],att))
    if b.erreurs or b.violations: ko.append('%s : %s'%(did[:14],(b.erreurs+b.violations)[:1]))
    b.fermer()
print('élèves vérifiés :',vus,'| écarts :',len(ko)); print('\n'.join(ko[:12]))
