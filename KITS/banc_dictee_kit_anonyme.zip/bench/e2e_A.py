"""De bout en bout, partie A — une classe neuve, une dictée neuve créée par le formulaire, des copies corrigées au geste.
Vérifie chaque copie enregistrée contre un calcul de note refait indépendamment (préparée ou brevet)."""
import sys, copy, json, random, math, os; sys.argv=['x','a','b']; sys.path.insert(0,'.')
import banc_L1 as L
from banc import Banc
F='../work/correction_dictee.html'; BAREME=os.environ.get('BAREME','preparee'); G=int(os.environ.get('GRAINE','1')); rnd=random.Random(G)
CLASSE='3E IMPORT TEST'; ELEVES=["ANDRÉ Zoé","DE LA FONTAINE Marie-Lou","N'DIAYE Aïssatou","LE GALL Jean","MZZOSOV-DUBOIS Élise","ÖZTÜRK Emre","PZZETUR Lou","VAN DER BERG Tom"]
TEXTE="L'été dernier, les enfants qu'on avait invités sont arrivés à l'improviste ; ils étaient fatigués mais heureux. Aujourd'hui, ils se sont promis de revenir : « Nous reviendrons ! » ont-ils crié."
TITRE='Dictée essai %s %d'%(BAREME,G)
bilan=[]
def note(n,ok,d=''):
    bilan.append(ok); print(('OK  ' if ok else 'KO  ')+n+('  — '+d if d else ''),flush=True)
def san(n):
    import unicodedata,re
    return re.sub(r'[^a-z0-9]+','_',''.join(c for c in unicodedata.normalize('NFD',n.lower()) if unicodedata.category(c)!='Mn')).strip('_')
COST={'G':1,'L':0.5,'M':1,'I':1,'X':0.5,'P':0.5,'A':0,'E':0.5}; COSTB={'G':1,'L':0.5,'M':0.5,'I':0.5,'X':0.5,'P':0,'A':0,'E':0.5}
def note_attendue(errs,extras,base):
    br=BAREME=='brevet'; C=COSTB if br else COST; vus={}; ded=0; nP=0
    for e in errs:
        k=str(e['word']).lower()+'|'+e['type']
        if br and k in vus: continue
        vus[k]=1
        if br and e['type']=='P': nP+=1; continue
        ded+=C[e['type']]
    ded+=len(extras)*C['X']
    if br: ded+=math.floor(nP/4)*0.5*(base/10)
    return round(max(0,base-ded)*10)/10
db=copy.deepcopy(L.BASE); db.setdefault('classes',{})[CLASSE]={'eleves':ELEVES}
b=Banc(F,1280,900); p=b.ouvrir('?mode=prof',db=db); p.wait_for_timeout(1200); p.on('dialog',lambda d: None)
# 1. créer la dictée par le formulaire
p.fill('input[placeholder="Ex: Dictée Maupassant ch.4"]',TITRE)
sels=p.query_selector_all('select'); 
p.evaluate("(a)=>{const ss=[...document.querySelectorAll('select')];const n=ss.find(s=>[...s.options].some(o=>o.value==='3e'));const c=ss.find(s=>[...s.options].some(o=>o.value===a));const set=(el,v)=>{const d=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set;d.call(el,v);el.dispatchEvent(new Event('change',{bubbles:true}))};set(n,'3e');set(c,a)}",CLASSE)
p.fill('textarea[placeholder="Colle le texte correct..."]',TEXTE); p.wait_for_timeout(300)
p.evaluate("()=>{const i=[...document.querySelectorAll('input[type=number]')][0];const d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;d.call(i,'10');i.dispatchEvent(new Event('input',{bubbles:true}))}")
bar=p.evaluate("(v)=>{const s=[...document.querySelectorAll('select')].find(s=>[...s.options].some(o=>o.value==='brevet'));if(!s)return 'pas de choix de barème';const d=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set;d.call(s,v);s.dispatchEvent(new Event('change',{bubbles:true}));return s.value}",BAREME)
p.get_by_role('button',name='Commencer').click(); p.wait_for_timeout(1800)
if BAREME=='brevet':
    # le barème se choisit dans le panneau ✏️ de la dictée (le formulaire de création ne le propose pas)
    p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Retour'));b&&b.click()}"); p.wait_for_timeout(900)
    p.evaluate("(t)=>{const c=[...document.querySelectorAll('div')].filter(d=>d.textContent.includes(t)&&d.querySelector('button[title=\"Éditer cette dictée\"]'));c[c.length-1].querySelector('button[title=\"Éditer cette dictée\"]').click()}",TITRE); p.wait_for_timeout(700)
    p.evaluate("()=>{const s=[...document.querySelectorAll('select')].find(s=>[...s.options].some(o=>o.value==='brevet'));const d=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set;d.call(s,'brevet');s.dispatchEvent(new Event('change',{bubbles:true}))}"); p.wait_for_timeout(200)
    p.evaluate("()=>{const s=[...document.querySelectorAll('select')].find(s=>[...s.options].some(o=>o.value==='brevet'));let c=s.closest('div');for(let k=0;k<8&&c;k++){const b=[...c.querySelectorAll('button.btn-primary')];if(b.length){b[b.length-1].click();return}c=c.parentElement}}"); p.wait_for_timeout(900)
    p.evaluate("(t)=>{const el=[...document.querySelectorAll('div')].filter(x=>x.children.length<12&&x.textContent.includes(t)&&x.textContent.includes('Ouvrir'));const c=el[el.length-1];[...c.querySelectorAll('button,a,span')].find(x=>x.textContent.trim().startsWith('Ouvrir')).click()}",TITRE); p.wait_for_timeout(1300)
dicts=b.lire(p,'correction_dictee') or {}; did=[k for k,v in dicts.items() if (v.get('config') or {}).get('title')==TITRE]
cfg=dicts[did[0]]['config'] if did else {}
note('1. dictée créée par le formulaire : titre, classe, base 10, texte ; barème %s'%(cfg.get('bareme') or 'préparée'),bool(did) and cfg.get('classe')==CLASSE and cfg.get('base')==10 and cfg.get('text')==TEXTE and (cfg.get('bareme') or 'preparee')==BAREME,str({k:cfg.get(k) for k in ('classe','base','bareme','niveau')}))
did=did[0] if did else None
if did and BAREME=='brevet' and cfg.get('bareme')!='brevet':
    note('   le barème brevet a été choisi',False,'config : %s'%cfg.get('bareme'))
toks=p.evaluate("()=>[...document.querySelectorAll('.word-grid button.word-btn')].map(b=>b.textContent)") if did else []
# 2. corriger chaque élève au geste (sauf un, absent)
def ouvrir_eleve(nom):
    court=nom.split(' ')[0][:1]+'. '+nom.split(' ')[-1]
    return p.evaluate("(n)=>{const x=[...document.querySelectorAll('*')].filter(e=>e.children.length===0&&e.textContent.trim()===n);if(!x.length)return false;(x[0].closest('button,[role=button],div[style*=cursor]')||x[0]).click();return true}",court)
def mots(): return p.evaluate("()=>[...document.querySelectorAll('.word-grid button.word-btn')].map(b=>b.textContent)")
from banc_L1 import BASE as _
attendu={}; absent=ELEVES[-1]
p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent==='←');b&&b.click()}"); p.wait_for_timeout(700)
for nom in ELEVES[:-1]:
    if not ouvrir_eleve(nom): note('   ouvrir %s'%nom,False); continue
    p.wait_for_timeout(700); T=mots()
    punct=[i for i,w in enumerate(T) if w in (',',';',':','.','!','«','»')]; apos=[i for i,w in enumerate(T) if w in ("'","’")]; motsi=[i for i,w in enumerate(T) if i not in punct and i not in apos]
    plan=[]; pris=set()
    for _ in range(rnd.randint(2,7) if BAREME!='brevet' else rnd.randint(5,11)):
        t=rnd.choice(['G','L','M','I','A','P','E','X','G','L'] if BAREME!='brevet' else ['G','L','M','I','A','P','P','P','E','X','G','L'])
        pool=punct if t=='P' else apos if t=='E' else motsi
        libres=[i for i in pool if i not in pris]
        if t=='X': plan.append(('X',rnd.choice(motsi),rnd.choice(['très','bien','les','donc']))); continue
        if not libres: continue
        i=rnd.choice(libres); pris.add(i); plan.append((t,i,None))
    errs=[]; extras=[]
    for t,i,w in plan:
        if t=='X':
            p.evaluate("(i)=>{const g=document.querySelector('.word-grid');const kids=[...g.children];const bs=kids.filter(k=>k.classList&&k.classList.contains('word-btn'));const b=bs[i];let n=b.nextElementSibling;while(n&&!(n.classList&&n.classList.contains('insert-zone')))n=n.nextElementSibling;n.click()}",i); p.wait_for_timeout(250)
            p.fill('input[placeholder="Le mot en trop..."]',w); p.get_by_role('button',name='Ajouter (−0,5)').click(); p.wait_for_timeout(250); extras.append({'afterIdx':i,'word':w}); continue
        p.evaluate("(i)=>document.querySelectorAll('.word-grid button.word-btn')[i].click()",i); p.wait_for_timeout(250)
        p.evaluate("(t)=>{const b=document.querySelector('.popup-btn-'+t.toLowerCase());b&&b.click()}",t); p.wait_for_timeout(250)
        fautif=None
        if t in ('G','L'):
            fautif=T[i]+'s'
            ok=p.evaluate("(v)=>{const i=[...document.querySelectorAll('.popup-overlay input')][0];if(!i)return false;const d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;d.call(i,v);i.dispatchEvent(new Event('input',{bubbles:true}));return true}",fautif); p.wait_for_timeout(150)
            p.keyboard.press('Enter'); p.wait_for_timeout(250)
        errs.append({'idx':i,'type':t,'word':T[i],'fautif':fautif})
    avant=p.evaluate("()=>document.body.innerText.slice(0,60).replace(/\\n/g,' ')")
    p.evaluate("()=>[...document.querySelectorAll('button')].find(x=>x.textContent.startsWith('Enregistrer')).click()"); p.wait_for_timeout(900)
    attendu[san(nom)]=(nom,errs,extras)
    if not b.lire(p,'correction_dictee/%s/results/%s'%(did,san(nom))): print('   DIAG copie absente pour',nom,'| écran avant Enregistrer :',avant,'| après :',p.evaluate("()=>document.body.innerText.slice(0,60).replace(/\\n/g,' ')"),flush=True)
    if p.evaluate("()=>!!document.querySelector('.word-grid')"): p.evaluate("()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent==='←');b&&b.click()}"); p.wait_for_timeout(600)
# 3. l'absent : clic droit, « Marquer absent »
court=absent.split(' ')[0][:1]+'. '+absent.split(' ')[-1]
p.evaluate("(n)=>{const x=[...document.querySelectorAll('*')].filter(e=>e.children.length===0&&e.textContent.trim()===n);const el=x[0].closest('button,[role=button],div[style*=cursor]')||x[0];el.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true,clientX:200,clientY:200}))}",court); p.wait_for_timeout(400)
p.evaluate("()=>{const b=[...document.querySelectorAll('*')].find(x=>x.children.length===0&&x.textContent.includes('Marquer absent'));b&&b.click()}"); p.wait_for_timeout(700)
R=(b.lire(p,'correction_dictee/%s/results'%did) or {}); A=b.lire(p,'correction_dictee/%s/absents'%did) or {}
ko=[]
for k,(nom,errs,extras) in attendu.items():
    r=R.get(k)
    if not r: ko.append('%s : pas de copie'%nom); continue
    re_=[x for x in (r.get('errors') or []) if x]; rx=[x for x in (r.get('extras') or []) if x]
    if sorted((e['idx'],e['type'],e['word']) for e in re_)!=sorted((e['idx'],e['type'],e['word']) for e in errs): ko.append('%s : erreurs %s ≠ %s'%(nom,[(e['idx'],e['type']) for e in re_],[(e['idx'],e['type']) for e in errs]))
    if sorted((x['afterIdx'],x['word']) for x in rx)!=sorted((x['afterIdx'],x['word']) for x in extras): ko.append('%s : mots en trop %s'%(nom,rx))
    na=note_attendue(errs,extras,10)
    if abs((r.get('note') or 0)-na)>1e-9: ko.append('%s : note %s ≠ %s attendu'%(nom,r.get('note'),na))
    fa=[e for e in errs if e.get('fautif')]; fr_=[x for x in re_ if x.get('fautif')]
    if len(fa)!=len(fr_): ko.append('%s : forme écrite par l’élève gardée %d/%d'%(nom,len(fr_),len(fa)))
note('2. %d copies corrigées au geste : erreurs, types, mots en trop, forme écrite, note exacte'%len(attendu),not ko,'; '.join(ko)[:400])
note('3. l’élève absent est rangé absent, sans copie',bool(A.get(san(absent))) and san(absent) not in R)
note('réseau : 0 accès au vrai hub, 0 erreur de page',not b.violations and not b.erreurs,str(b.violations+b.erreurs)[:150])
json.dump({'db':b.lire(p,''),'did':did,'attendu':attendu},open('/tmp/e2e_%s.json'%BAREME,'w'))
b.fermer(); print('\nBILAN : %s'%('TOUT PASSE' if all(bilan) else 'ÉCHEC'))
